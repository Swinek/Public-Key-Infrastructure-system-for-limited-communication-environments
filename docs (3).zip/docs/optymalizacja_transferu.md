# Optymalizacja transferu CRL w sieci P2P

> **Charakter dokumentu: cel / projekt** (2026-10-22), nie stan implementacji.

Dwie metody ograniczania ruchu:

1. **co** przesyłać: dynamiczna delta albo pełna CRL, zależnie od tego, co jest mniejsze;
2. **kiedy** przesyłać: tylko przy nawiązaniu łączności P2P albo gdy węzeł z internetem dostanie nową CRL;
3. **mniejsza CRL**: podpis ECDSA P-256 zamiast RSA, kompresja, krótsze numery seryjne, usuwanie wygasłych wpisów, DER zamiast PEM;
4. **pamięć wymiany z każdym sąsiadem**: ta sama wersja nie jest wysyłana drugi raz po ponownym połączeniu.

---

## 1. Dynamiczna delta albo pełna CRL

Każda CRL ma `CRLNumber`. Węzeł, który chce aktualizacji, podaje numer, który już ma (`have=m`).
Nadawca wybiera **mniejszą** z dwóch odpowiedzi:

- **skumulowaną deltę-CRL** z bazą ≤ *m* (wszystkie zmiany od *m* do aktualnej wersji),
- **pełną CRL**, jeśli delty dla bazy *m* nie ma (węzeł był odcięty zbyt długo) albo jest od niej większa.

Gdy odbiorca ma już aktualny numer, nic nie jest przesyłane.

Delty podpisuje CA, a pośrednicy przekazują je dalej bez zmian. Odbiorca łączy deltę ze swoją pełną CRL
zgodnie z RFC 5280 §5.2.4 (delta o bazie *M* pasuje do każdej pełnej CRL o numerze ≥ *M*).

Zysk: kilka nowych odwołań to delta rzędu setek bajtów zamiast pełnej CRL rzędu setek KB.

---

## 2. Kiedy przesyłać: dwa wyzwalacze

Bez okresowego odpytywania. Gdy węzły mają tę samą wersję, łącze milczy.

**Wyzwalacz A: węzeł z internetem dostał nową CRL.**
Weryfikuje ją (podpis CA, `CRLNumber` większy niż lokalny) i powiadamia sąsiadów:
`announce {crl_number}`. Sąsiad z niższym numerem pobiera aktualizację metodą z §1, weryfikuje
i sam powiadamia swoich sąsiadów. CRL rozchodzi się krok po kroku po całej sieci.

**Wyzwalacz B: nawiązanie łączności P2P.**
Węzły wymieniają numery CRL. Ten, który ma niższy, pobiera aktualizację metodą z §1.
Jeśli wcześniejsze `announce` nie doszło (łącze było zerwane), węzeł pamięta zaległość
i wysyła je po odzyskaniu łączności.

```
portal → 1:  CRL 11                        (1 ma internet)
1 → 2:  announce 11, 2 ma 10  →  2 pobiera deltę 11/base 10
2 → 3:  announce 11, 3 ma 10  →  3 pobiera deltę 11/base 10
```

---

## 3. Mniejsza CRL

**Algorytm podpisu: ECDSA P-256 z SHA-256 (decyzja 2026-10-22).** Dla CA i wszystkich certyfikatów (użytkowników,
węzłów) używamy ECDSA P-256 z SHA-256, bo zmniejsza podpis z 512 B do około 72 B i działa z OpenSSL, EJBCA
i Dogtag bez żadnych problemów ze zgodnością.
- Podpis CA jest w każdym certyfikacie, pełnej CRL i delcie, a przy małych CRL to on stanowi większość rozmiaru
  (delta z dwoma odwołaniami: ~700–800 B przy RSA-4096, ~250–300 B przy P-256).
- Ed25519 (podpis 64 B, RFC 8410) odrzucony ze względu na słabsze wsparcie w systemach CA i HSM; zostaje
  w tabeli porównawczej w pracy (RSA vs ECDSA vs Ed25519, rzeczywiste rozmiary CRL i delt).
- Podpis ECDSA w DER ma zmienną długość (~70–72 B), więc w pomiarach rozmiaru możliwe wahania o 1–2 B.
- Stan kodu: CA dziś RSA-4096 (`admin/backend/pki/ca.py:55`), klucze użytkowników RSA-2048 (`ca.py:123`).
  Zmiana: `ec.generate_private_key(ec.SECP256R1())` i wygenerowanie CA od nowa, najlepiej przed implementacją
  wymiany CRL między węzłami, żeby pomiary od razu dotyczyły docelowego algorytmu.

**Kompresja.** CRL jest pakowana przed wysłaniem (np. zlib). Podpis zostaje nienaruszony, bo po rozpakowaniu
bajty DER są te same. Daje 30–60% mniej danych.

**Krótsze numery seryjne.** Dziś numer seryjny ma około 20 bajtów (losowe 159 bitów), a wystarczy 8 (64 bity
losowe). Każdy wpis na CRL robi się wtedy prawie o połowę mniejszy.

**Usuwanie wygasłych wpisów.** Wpis odwołanego certyfikatu można skreślić z listy, kiedy ten certyfikat i tak
wygaśnie (RFC 5280 §5.1.2.6), więc CRL nie rośnie bez końca. Uwaga: węzeł z cofniętym zegarem uzna wtedy
taki certyfikat za ważny i nieodwołany, dlatego wpis warto trzymać jeszcze przez pewien margines po `notAfter`.

**DER zamiast PEM.** To ta sama CRL w dwóch zapisach: DER to surowe bajty, PEM to te same bajty zakodowane
tekstem (base64) z nagłówkami `-----BEGIN X509 CRL-----`, przez co jest o około 1/3 większy. Podpis jest liczony
z bajtów DER, więc w obu formach jest ten sam. Między węzłami przesyłamy i przechowujemy DER (`crl.der`, typ
`application/pkix-crl`, RFC 2585); PEM zostaje tylko do pobierania przez człowieka w portalu. Przy kompresji
różnica maleje, ale DER nadal jest mniejszy, także na dysku.

Co trzeba zmienić w kodzie (stan na 2026-10-22):
- CA: plik DER już jest zapisywany (`admin/backend/pki/ca.py`, `CRL_DER_PATH`), wystarczy go wysyłać;
- portal klienta: dziś zwraca `crl.pem` (`edge_client/backend/routers/certificates.py`), trzeba dodać DER;
- węzły (`edge_app/`): wymiany CRL jeszcze nie ma, od początku robić ją w DER;
- `scripts/demo_offline_auth.py`: wczytuje PEM (`load_pem_x509_crl`), trzeba obsłużyć DER; w OpenSSL ewentualnie `-inform DER`.

---

## 4. Pamięć wymiany z każdym sąsiadem

Każdy węzeł trzyma tabelkę: który sąsiad ma którą wersję CRL (np. „statek 2 → 11”). Przy ponownym połączeniu
sprawdza tabelkę i jeśli sąsiad ma już ten sam numer, nic nie wysyła. Statek, który rozłączy się i połączy
10 razy w ciągu 10 minut, dostanie listę tylko raz.

- **Wpis dopiero po potwierdzeniu.** Numer zapisujemy, gdy sąsiad potwierdzi odbiór i poprawną weryfikację,
  a nie w chwili wysłania. Zerwane w połowie wysyłanie nie może oznaczyć sąsiada jako aktualnego.
- **Sąsiad mógł stracić dane** (np. restart bez dysku). Przy każdym połączeniu węzły i tak wymieniają sam numer
  CRL (kilka bajtów, §2), więc nieaktualna tabelka wychodzi od razu na jaw.
- **Sąsiad mógł dostać nowszą od kogoś innego.** Wtedy tylko aktualizujemy tabelkę.
- **Tabelka jest zapisana na dysku**, żeby przetrwała restart węzła.

---

## Bezpieczeństwo

Numer w `announce` jest niezaufany i służy tylko do decyzji, czy pobierać. CRL przyjmuje się wyłącznie
po weryfikacji podpisu CA i gdy `CRLNumber` jest większy niż lokalny, co wyklucza też podmianę na starszą wersję.
