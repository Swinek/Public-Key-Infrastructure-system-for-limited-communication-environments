 # Plan wdrożenia – lista zadań

> **Charakter dokumentu: cel / plan** (2026-10-21, struktura zaktualizowana 2026-10-24). Opisuje, co trzeba zrobić,
> a nie stan obecny.
> Mapowanie diagramu (2026-10-24): **Łączność** = `client.sh` (`internet on/off`, `link up/down`),
> **Panel administratora** = `admin/` (3000), **Edge client** = `edge_client/` (backend publikacji 5001 +
> węzły `edge_client/node`, kontenery `client_N`, UI 3011–3013), **Edge app** = `edge_app/` (kontenery `app_N`,
> 8001–8003). **Dystrybucja PKI (WAN, P2P, CRL, CA, statystyki transferu) należy do Edge clienta**
> (`edge_client/node/`); Edge app tylko pobiera pakiet od swojego Edge clienta i uwierzytelnia się w `app_net`.
> Weryfikator jest jeden: `edge_app/pki/`, wspólny dla obu komponentów.
> Kolejność ma znaczenie: każdy etap korzysta z poprzedniego.

Oznaczenia: **[MUST]** – potrzebne do obrony, **[OPC]** – opcjonalne.

---

## Etap 0 – porządki (zrobione 2026-10-21)

- [x] **[MUST]** Dodać `pki_data/` do `admin/backend/.dockerignore` i trzymać klucz CA na wolumenie (dziś trafia do obrazu Dockera).
- [x] **[MUST]** Przerobić `scripts/demo_offline_auth.*`: certyfikat testowy ma wydawać CA przez API, a skrypt ma tylko weryfikować (dziś podpisuje kluczem CA). Poprawić stare ścieżki `backend/pki_data`.
- [x] **[MUST]** Zostawić **dwa osobne compose** (centrum i `edge_app/`) i połączyć je wspólną siecią zewnętrzną `internet_net`: w `docker-compose.yml` dodać `edge-client-backend` do `internet_net` z `external: true`. Wtedy `internet on` daje węzłom dostęp do portalu klienta, a nie tylko do publicznego internetu (zob. `AGENTS.md`).
- [x] **[MUST]** Trzeci węzeł w `edge_app/` i łańcuch 1 ↔ 2 ↔ 3 (lista sąsiadów zamiast jednego `PEER_IP`), żeby pokazać przekazywanie danych przez pośrednika.
- [x] **[MUST]** Wolumen na dane węzła (dziś pliki i skrzynka giną po restarcie).
- [x] **[MUST]** Szkielet testów `pytest` (folder `tests/`).
- [x] Sprzątanie: duplikaty `edge_client/frontend/main.jsx` i `index.css`, martwy `import hashlib` w `edge_app/routers/p2p.py`, nieaktualne `scripts/*.pem`.

## Etap 1 – poprawne dane PKI w CA (zrobione 2026-10-22)

- [x] **[MUST]** Nowe Root CA z rozszerzeniami SKI i `KeyUsage(keyCertSign, cRLSign)`. Certyfikaty węzłów z AKI, SKI i KeyUsage (bez AKI biblioteka weryfikująca je odrzuca). Rozważyć klucz EC P-256 zamiast RSA (mniejsze CRL).
- [x] **[MUST]** Numer CRL (`CRLNumber`, rośnie przy każdej nowej liście) i AKI w CRL – ochrona przed podsunięciem starej listy.
- [x] **[MUST]** CRL podpisywana tylko przy odwołaniu i okresowo (np. co 24 h), zapisywana do bazy (tabela `crls`). `GET /crl` zwraca zapisaną listę zamiast podpisywać nową.
- [x] **[MUST]** Portal klienta czyta certyfikat CA i CRL z bazy (usunąć proxy HTTP do admina), na koncie bazy tylko do odczytu.
- [x] **[MUST]** Endpointy dla węzłów w portalu: `/pki/summary` (numery i rozmiary), `/pki/ca`, `/pki/crl`, `/pki/certs`.

## Etap 2 – węzeł weryfikuje offline

> Stan 2026-10-23: moduł `edge_app/pki/` (magazyn + weryfikator + `check_certificate`) z testami zrobiony.
> Przyjęte domyślne decyzje: certyfikat węzła = użytkownik CA o nazwie równej `NODE_ID`; przypięcie CA przez
> `CA_FINGERPRINT` (env), a bez niego TOFU – pierwsze zainstalowane CA zostaje przypięte w `ca.pin`;
> instalacja przyjmuje certyfikat + klucz (przejście na CSR – Etap 3). Wynik weryfikatora ma czwartą wartość
> `invalid` (obce CA, wygasły) obok `valid` / `revoked` / `unknown`.

- [x] **[MUST]** Wgrywanie do węzła certyfikatu, klucza i certyfikatu CA (wolumen albo endpoint, np. `POST /api/pki/install`). Certyfikat CA z przypiętym fingerprintem. *(`POST /api/pki/install`, multipart `ca`/`cert`+`key`/`crl`, PEM lub DER)*
- [x] **[MUST]** Logika PKI jako osobny moduł `edge_app/pki/`, oddzielony od aplikacji. Aplikacja tylko pyta „czy ten certyfikat jest OK?”.
- [x] **[MUST]** Lokalny magazyn PKI w `edge_app/pki/`: certyfikat CA, własny certyfikat, ostatnia CRL. Zapis atomowy (najpierw plik tymczasowy, potem podmiana).
- [x] **[MUST]** Weryfikator offline w `edge_app/`: łańcuch do Root CA, okres ważności, status w CRL. Wynik: `ważny` / `odwołany` / `nieznany (dane nieaktualne)`. Czas „teraz” podawany z zewnątrz (dla testów).
- [x] **[MUST]** Endpoint `POST /api/pki/verify` i podgląd stanu PKI w panelu węzła. *(+ `GET /api/pki/status`, zakładka „PKI” w panelu; `verify` przyjmuje opcjonalny czas `at`)*

## Etap 3 – dystrybucja danych (Edge client, `edge_client/node/`)

> Stan 2026-10-24: wszystkie zadania MUST z pełną CRL zrobione (testy `tests/edge_client/test_pki_sync.py`,
> `test_saf.py`, `test_transfers.py`, `test_contact.py`). Zostają: delta-CRL [LATER] i CSR – rozpisany w Etapie 3b.

> Gotowe wcześniej: endpointy portalu `/pki/summary|ca|crl|certs` (DER, ETag/304), kontrola CRL przed zapisem
> (`certs.CertStore.update_crl`: podpis CA, issuer, rosnący `CRLNumber`, zapis atomowy), wykrywanie sąsiadów
> jednorazowym hello (`edge_client/node/neighbours.py`).

- [x] **[MUST]** Wyzwalacze kontaktu (2026-10-24, `edge_client/node/contact.py`): `client.sh internet on` →
  `POST /api/contact/wan` (kontakt z portalem), odebrane hello / hello-ack → kontakt z tym sąsiadem. Bez timerów
  i bez odpytywania – tylko zdarzenia Łączności. Jedna wymiana naraz na źródło, dziennik w `GET /api/contact/events`.
  Synchronizacja CRL/CA i store-and-forward podpinają się jako obsługa tych zdarzeń.
  Trzeci wyzwalacz (2026-10-24): **wydanie nowej CRL w CA** – `pg_notify('crl_issued')` w
  `admin/backend/pki/store.py`, portal nasłuchuje (`edge_client/backend/announce.py`, LISTEN) i od razu wysyła
  `POST /api/contact/wan` do węzłów online (te, które pobrały `/pki/summary` przez WAN; `GET /pki/online`).
  Sprawdzone: CRL nr 58 z panelu → client_1 → client_2 w kilka sekund, bez komendy `client.sh`.
- [x] **[MUST]** Rejestrowanie rozmiaru przesyłanych danych (2026-10-24, `edge_client/node/transfers.py` +
  `wire.py`): `transfers.record(...)` przy każdym wysłaniu (`out`) i odbiorze (`in`) – rodzaj (`summary`, `crl_full`,
  `ca_cert`, `msg`, `file`, `saf_offer`, `announce`; `crl_delta`/`cert` zarezerwowane), kodowanie, algorytm podpisu,
  `CRLNumber`/`msg_id`, sąsiad; `payload_bytes` i `wire_bytes` (żądanie + odpowiedź HTTP z nagłówkami, szacunek
  bez TCP/IP); status `ok`/`skipped` (z `saved_bytes` – sąsiad już miał tę wersję)/`rejected`/`aborted`. Wyniki:
  linia `[TRANSFER]` w logu, `DATA_DIR/transfers.jsonl`, `GET /api/stats/transfers` (`?format=csv`, `DELETE` czyści),
  `./client.sh stats [N] [csv]`, `stats-reset`. Zapytania lokalne i z UI (spoza `P2P_CIDR`) nie są liczone.
  Kompresja – jeszcze brak (pole `encoding` gotowe).
- [x] **[MUST]** Edge client udostępnia sąsiadom te same endpointy co portal (`/pki/summary`, `/pki/ca`, `/pki/crl`,
  DER/PEM, ETag/304) – `edge_client/node/routers/pki.py`, serwowane są oryginały podpisane przez CA.
- [x] **[MUST]** Synchronizacja CRL przy kontakcie (`edge_client/node/pki_sync.py`): `summary`, pobranie tylko
  nowszej CRL, `update_crl` przed zapisem, przerwanie pobierania po przekroczeniu rozmiaru z `summary`
  (i twardego `MAX_PKI_OBJECT_BYTES`). Nowa CRL → `announce` do pozostałych sąsiadów (`POST /api/contact/announce`),
  którzy sami ją pobierają – zdarzenie, nie timer. Wyzwalacz w trakcie wymiany z tym samym peerem nie ginie
  (jedna dodatkowa runda). `link up a b`: hello tylko od a i tylko na nowym łączu (jedna wymiana w każdą stronę).
  Sprawdzone na Dockerze: CRL nr 53 z CA → client_1 (WAN) → client_2 (announce) → client_3 (`link up 2 3`).
- [x] **[MUST]** Ten sam mechanizm dla certyfikatu CA. **Decyzja (domyślna, 2026-10-24):** z portalu (WAN) albo
  ręcznie; od sąsiada tylko przy przypiętym `CA_FINGERPRINT` (env Edge clienta, sprawdzany też przy ręcznym wgraniu).
  Własny certyfikat węzła przez tę ścieżkę dopiero razem z CSR (portal nie wydaje klucza).
- [x] **[MUST]** Store-and-forward wiadomości i plików do węzłów spoza zasięgu (`edge_client/node/saf.py`,
  `routers/saf.py`): trwała kolejka `DATA_DIR/saf/` (+ `seen.json`), przy kontakcie `POST /api/saf/offer` z listą
  znanych `msg_id` (prefiks 16 hex) → tylko brakujące; plik osobnym `GET` ze sprawdzeniem rozmiaru i SHA-256; TTL
  od utworzenia (`SAF_TTL_HOURS`, pośrednik nie przedłuża), limit skoków, odrzucanie pętli. **Decyzja (domyślna,
  2026-10-24): epidemic** – bez znajomości topologii kopia u każdego sąsiada to jedyny sposób dotarcia; duplikaty
  blokuje wymiana list id. Do rozważenia w Etapie 4: potwierdzenia doręczenia (usuwanie kopii po doręczeniu),
  limit rozmiaru kolejki.
- [ ] **[LATER]** Delta-CRL (zob. `AGENTS.md`): CA podpisuje listy zmian od kilku ostatnich wersji, a węzeł pobiera mniejszy obiekt (deltę albo pełną listę). Robić **po** działającej pełnej CRL.
- [ ] **[MUST]** Klucz prywatny nie podróżuje: węzeł generuje klucz i CSR, CA zwraca tylko certyfikat – rozpisane w Etapie 3b.
- [x] **[OPC]** CSR i certyfikat przesyłane przez sąsiadów (gdy węzeł nie ma internetu) – rozpisane w Etapie 3c.

### Etap 3b – bezpieczne wprowadzanie tożsamości węzła (decyzja 2026-10-24)

> Powód: dziś certyfikat **z kluczem prywatnym** i Root CA wgrywa się przez panel Edge clienta (3011–3013,
> `POST /api/certs`, `client.sh cert-upload`), bez uwierzytelnienia. Fałszywej tożsamości nie da się wgrać
> (podpis CA, zgodność klucza), ale: (1) klucz prywatny opuszcza CA i wędruje przez ręce administratora,
> (2) każdy z dostępem do panelu może podmienić parę certyfikat + klucz na inną ważną (np. innego węzła),
> (3) bez `CA_FINGERPRINT` pierwsze wgrane CA jest przyjmowane na zaufanie (TOFU) – można podsunąć własne CA.
> To przeczy idei projektu: dane PKI wędrują jako dane publiczne podpisane przez CA, a sekrety nie opuszczają węzła.

> Stan 2026-10-24: zrobione (poza [OPC]). Decyzja autora: **administrator zatwierdza każdy wniosek** (bez
> automatycznego podpisu). Sprawdzone na Dockerze: odwołanie certyfikatu client_3 w CA → impuls → client_3 pobiera
> CRL, widzi swój certyfikat jako odwołany i sam wysyła CSR → „Zatwierdź” w panelu → impuls `cert_issued` →
> client_3 instaluje nowy certyfikat → `client.sh auth 3 2` przechodzi.

- [x] **[MUST]** Klucz węzła powstaje w Edge cliencie (`edge_client/node/enroll.py`, `certs.new_request`): EC P-256,
  `pending_key.pem` (`0600`) + CSR z CN = `NODE_ID`; obecny certyfikat działa do instalacji nowego. Wniosek idzie
  sam, gdy certyfikatu brak, jest odwołany / od obcego CA albo kończy się za `RENEW_BEFORE_DAYS` (30) dni.
- [x] **[MUST]** CA przyjmuje CSR i zwraca **tylko certyfikat**: tabela `csr_requests` (tworzona przy starcie CA,
  `admin/backend/pki/store.py`), `GET /api/csr`, `POST /api/csr/{id}/approve|reject` (`admin/backend/routers/csr.py`),
  podpis na klucz z wniosku (`pki/ca.sign_csr`: sprawdzenie podpisu CSR, CN = węzeł, klucz EC P-256), rejestracja
  węzła przy pierwszym zatwierdzeniu, odwołanie poprzedniego certyfikatu (`superseded`) + nowa CRL, NOTIFY
  `cert_issued`. Zakładka „Wnioski CSR” w panelu (`admin/frontend/src/CsrPanel.jsx`). Po odrzuceniu węzeł nie ponawia
  wniosku sam (`client.sh csr N` / przycisk w panelu węzła). **Zostaje:** `POST /api/certificates` z kluczem
  generowanym w CA – używają go tylko `scripts/demo_offline_auth.*`; do usunięcia razem z przeróbką skryptów.
- [x] **[MUST]** Dostarczenie wniosku i certyfikatu tą samą drogą co CRL (kontakt WAN, pull): portal
  `POST /pki/csr` (sprawdza podpis CSR, jeden oczekujący wniosek na węzeł; konto portalu ma tylko `INSERT` na
  `csr_requests`), `GET /pki/csr/{odcisk klucza}` → numer seryjny → `/pki/certs/{serial}`. Węzeł instaluje certyfikat
  tylko podpisany przez przypięty Root CA i na **własny** oczekujący klucz (`certs.install_issued`). Transfery
  `csr` / `cert` w rejestrze.
- [x] **[OPC]** CSR i certyfikat przez sąsiadów (store-and-forward), gdy węzeł nie ma internetu – Etap 3c.
- [x] **[MUST]** Root CA przypięty przy wdrożeniu: `client.sh up` liczy odcisk z publicznego
  `admin/backend/pki_data/ca_certificate.pem` i zapisuje `CA_FINGERPRINT` w `.env` (w `.gitignore`), compose przekazuje
  go do `client_N` i `app_N`. Bez pinu Edge client nie przyjmuje żadnego CA (koniec TOFU).
- [x] **[MUST]** Panel Edge clienta bez wgrywania sekretów: usunięte `POST /api/certs` (certyfikat/klucz/CA),
  `client.sh cert-upload`, karta „Upload”. Zostaje: podgląd, pobranie certyfikatu, sprawdzenie offline, „New key +
  request” (`POST /api/certs/csr`, `client.sh csr`) i CRL z nośnika (`POST /api/certs/crl`, `client.sh crl-upload`).
- [ ] **[OPC]** Uwierzytelnienie operacji zmieniających stan w panelu węzła (token operatora / dostęp tylko z `mgmt_N`)
  – dziś każdy z dostępem do portu 3011–3013 może wywołać CSR, wgrać CRL, wysłać wiadomość.
- [x] **[MUST]** Testy: `tests/edge_client/test_enroll.py` (wniosek → instalacja po zatwierdzeniu, klucz nie wychodzi,
  odrzucony nie wraca, certyfikat na cudzy klucz odrzucony, odwołany → nowy wniosek, nie nowy certyfikat),
  `test_certs.py` (brak wgrywania – 405, CRL tylko podpisana i nowsza), `test_portal_csr.py`,
  `tests/admin/test_csr_signing.py`, `test_pki_sync.py` (bez pinu żadne CA).

### Etap 3c – wniosek CSR i certyfikat przez sąsiadów (plan 2026-10-24)

> Dziś CRL wędruje w dół (CA → węzeł z internetem → sąsiedzi), ale wniosek CSR idzie tylko bezpośrednio:
> `enroll.py` działa wyłącznie przy kontakcie WAN. Węzeł bez internetu (np. client_3 za client_2) nie dostanie
> certyfikatu, dopóki sam nie dostanie internetu. Cel: CSR przechodzi przez kilka węzłów do portalu, a wydany
> certyfikat wraca tą samą metodą. CSR i certyfikat to dane publiczne (CSR podpisany kluczem węzła, certyfikat
> podpisany przez CA), więc pośrednik nie musi być zaufany – przenosi je store-and-forward (`saf.py`), a cel sprawdza.
>
> Przepływ (client_3 bez internetu, client_1 z internetem, łańcuch 3 ↔ 2 ↔ 1):
> ```
> client_3: brak certyfikatu → klucz + CSR → element SAF {type: csr, destination: portal}
> 3 → 2 → 1 (zwykła wymiana SAF przy kontakcie / announce)
> client_1 (kontakt WAN): POST /pki/csr (w imieniu client_3), zapamiętuje odcisk klucza jako „przenoszony”
> administrator: Zatwierdź → NOTIFY cert_issued → portal budzi węzły online (client_1)
> client_1: GET /pki/csr/<odcisk> → APPROVED → GET /pki/certs/<serial> → element SAF {type: cert, destination: client_3}
> 1 → 2 → 3: client_3 instaluje certyfikat tylko, jeśli podpisał go przypięty Root CA i jest na jego własny klucz
> ```
>
> Stan 2026-10-24: zrobione. `edge_client/node/relay.py` (przekazanie do portalu, `relayed.json`, odbiór decyzji),
> typy `csr` / `cert` / `csr_result` w `saf.py`, ścieżka radiowa w `enroll.py` (`RELAYED`), nagłówek `X-PKI-Route`
> → kolumna `relayed_via` (portal, panel CA). Element CSR trafia do portalu od razu, gdy przewoźnik ma internet
> (hak `saf.on_queued`), bez czekania na kolejny kontakt WAN. Testy `tests/edge_client/test_relay.py`
> (3 węzły w jednym procesie). Na Dockerze: CSR 3 → 2 → 1 → portal i certyfikat z powrotem, `auth 3 2` przechodzi;
> skoki kosztują CSR 208 B (≈520–960 B na łączu), certyfikat 508 B (≈820–1260 B).

- [x] **[MUST]** Nowe typy elementów store-and-forward w `saf.py`: `csr` (adresat specjalny `portal`, treść = CSR w DER,
  limit 4 KB) i `cert` (adresat = węzeł z CN, treść = certyfikat w DER, limit `MAX_PKI_OBJECT_BYTES`). Te same zasady co
  dla wiadomości: TTL od utworzenia, limit skoków, pętle, lista znanych `msg_id`, sprawdzenie rozmiaru i SHA-256.
  **Deterministyczne `msg_id`** – dla `csr` odcisk klucza, dla `cert` SHA-256 certyfikatu – żeby kopie u różnych
  pośredników były jednym elementem (bez duplikatów w portalu i w sieci).
- [x] **[MUST]** Walidacja treści u każdego pośrednika przed przyjęciem do kolejki (nie tylko u celu): `csr` – poprawny
  podpis CSR i CN = `origin_id`; `cert` – podpisany przez przypięty Root CA i CN = `destination_id`. Śmieci nie zajmują
  łącza na kolejnych skokach.
- [x] **[MUST]** Węzeł bez internetu wysyła wniosek przez sąsiadów (`enroll.py`): gdy potrzebuje certyfikatu
  (`needs_certificate`) i ma wniosek w stanie `NEW`, przy kontakcie z sąsiadem (handler dla `NEIGHBOUR`) wkłada CSR
  do kolejki SAF i oznacza wniosek jako `RELAYED`. Jeśli potem sam dostanie internet, idzie też ścieżka bezpośrednia
  (portal przyjmuje ten sam klucz idempotentnie).
- [x] **[MUST]** Przekazanie do portalu przez węzeł z internetem (nowy krok w kontakcie WAN): elementy `csr`
  z adresatem `portal` → `POST /pki/csr`; po przyjęciu element znika z kolejki (oznaczony jako doręczony), a odcisk
  klucza trafia do `DATA_DIR/saf/relayed.json` {odcisk, węzeł, czas}. Odpowiedź 409 (inny oczekujący wniosek węzła)
  też kończy przenoszenie – decyzja należy do administratora.
- [x] **[MUST]** Odbiór certyfikatu przez przewoźnika: przy każdym kontakcie WAN (w tym po impulsie `cert_issued`)
  węzeł sprawdza `GET /pki/csr/<odcisk>` dla przenoszonych wniosków; `APPROVED` → pobiera `/pki/certs/<serial>`,
  sprawdza podpis CA i tworzy element SAF `cert` do węzła z wniosku, a wpis z `relayed.json` usuwa. `REJECTED` →
  element informacyjny `csr_result` (niepodpisany, więc węzeł traktuje go tylko jako podpowiedź „odrzucony wg
  pośrednika”; ostateczny status potwierdza dopiero własny kontakt WAN). Wpisy starsze niż `SAF_TTL_HOURS` są usuwane.
- [x] **[MUST]** Instalacja u celu: element `cert` dla tego węzła nie trafia do skrzynki, tylko do
  `certs.install_issued` (podpis przypiętego Root CA + własny oczekujący klucz); certyfikat na cudzy klucz jest
  odrzucany i zapisany w rejestrze transferów jako `rejected`.
- [x] **[MUST]** Ochrona przed podsunięciem cudzego klucza: pośrednik może złożyć w portalu wniosek z CN = client_3
  i własnym kluczem – dlatego administrator zatwierdza każdy wniosek. W panelu węzła widać odcisk klucza
  oczekującego wniosku, a w panelu CA ten sam odcisk i trasę (`hops`, nowa kolumna `relayed_via` w `csr_requests`
  zapisywana przez portal) – do porównania poza systemem (np. przez radio/telefon) przed zatwierdzeniem.
- [x] **[MUST]** Rejestr transferów: `csr` / `cert` z kierunkiem, sąsiadem i statusem także dla przenoszonych kopii
  (pomiar: ile bajtów kosztuje wydanie certyfikatu węzłowi odciętemu o N skoków).
- [x] **[MUST]** Testy: CSR 3 → 2 → 1 → portal i certyfikat z powrotem (podstawiony portal); pośrednik odrzuca
  śmieciowy CSR / certyfikat obcego CA; certyfikat na cudzy klucz nieinstalowany; duplikaty od dwóch przewoźników =
  jeden wniosek; rejection z pośrednika nie blokuje ostatecznie węzła.
- [x] **[MUST]** Scenariusz na Dockerze: `internet on 1`, łańcuch 1 ↔ 2 ↔ 3, client_3 bez certyfikatu (`client.sh csr 3`)
  → wniosek w panelu CA → „Zatwierdź” → certyfikat u client_3 bez internetu; `client.sh auth 3 2` przechodzi;
  `client.sh stats` pokazuje bajty CSR/certyfikatu na każdym skoku.

## Etap 4 – nieaktualność danych i bezpieczeństwo

- [ ] **[MUST]** Polityka świeżości: po `nextUpdate` okres łaski (np. 72 h), potem odrzucanie. Komunikat „PKI nieaktualne od X h”.
- [ ] **[MUST]** Tolerancja rozjazdu zegara (np. ±5 min). Czas węzła nie może być wcześniejszy niż najnowsza widziana CRL.
- [ ] **[MUST]** Ochrona przed zaśmiecaniem: limity rozmiaru i częstotliwości w P2P (Edge client, `edge_client/node/`).
- [x] **[MUST]** Użycie certyfikatu w praktyce: uwierzytelnienie przez wyzwanie → podpis → weryfikacja offline (zrobione: `edge_app/routers/auth.py`, kanał `app_net`, `client.sh auth 1 2`).
- [ ] **[OPC]** mTLS między węzłami, Root CA + pośrednie CA, odpowiedzi OCSP liczone tylko do porównania.

## Etap 5 – testy i demonstracja

- [ ] **[MUST]** Testy weryfikatora, z wynikiem porównanym z `openssl verify -crl_check -use_deltas`:
  - certyfikat ważny, odwołany, wygasły;
  - CRL przeterminowana;
  - delta bez bazy;
  - CRL obcego CA.
- [ ] **[MUST]** Testy złośliwego pośrednika: zmieniona CRL, starsza CRL, obce CA, przerwany transfer → węzeł odrzuca i zostaje w poprzednim stanie.
- [ ] **[MUST]** Skrypty scenariuszy na Dockerze:
  1. Wszystkie węzły offline – weryfikacja nadal działa.
  2. Odwołanie, gdy węzeł 3 jest odcięty – CRL dociera do niego przez węzeł 2. Mierzymy liczbę skoków i przesłanych bajtów (bez pomiaru czasu – łącza P2P to sieci Docker bez opóźnień).
  3. Brak nowej CRL – przejście: ważny → okres łaski → odrzucenie.
  4. Rozjazd zegara (podany czas albo `libfaketime`).
- [ ] **[MUST]** Pomiar bajtów przesłanych P2P: „zawsze pełna CRL” vs „zawsze delta” vs „adaptacyjnie”.
- [ ] **[MUST]** Skrypt porównawczy rozmiarów `scripts/bench_sizes.py` (niezależny od Dockera): CRL dla N = 0, 10, 100, 1000 odwołań w wariantach RSA/ECDSA × PEM/DER × pełna/delta × z kompresją i bez, plus certyfikat i certyfikat CA. Wynik jako tabela i CSV do pracy. Podpis ECDSA ma zmienną długość (±1–2 B), więc wyniki uśredniać z kilku prób.
- [ ] **[MUST]** Poprawić diagram (`architecture.png`) i README do stanu końcowego:
  - dwie ramki zamiast jednej „docker compose”: „centrum” i „okręt”;
  - Łączność jako przełącznik łącza;
  - strzałka „SQL (READ)” wychodząca z portalu klienta;
  - „crl” na połączeniu między Edge clientami (`edge_client/node`, sieci `p2p_<ab>`).

## Praca pisemna (równolegle)

- [ ] Przegląd PKI: X.509 / RFC 5280, CRL, delta-CRL, OCSP, PKCS#10/#12, OpenSSL, EJBCA, Dogtag (materiał: `docs/przeglad_narzedzi.md`).
- [ ] Problem ograniczonej łączności i model zagrożeń.
- [ ] Projekt i implementacja systemu.
- [ ] Wyniki testów i pomiarów.
