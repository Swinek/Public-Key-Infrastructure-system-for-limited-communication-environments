# Przegląd narzędzi, bibliotek i standardów dla PKI o ograniczonej łączności

> **Charakter dokumentu: cel / analiza** (stan na 2026-10-20). Dokument nie opisuje zrealizowanej implementacji
> i nie zmienia kodu. Numery `#NN` odnoszą się do tabel w `docs/rozbieznosci_architektura_kod.md`,
> a „docs §N” – do sekcji `docs/architektura_docelowa.md`.
>
> **Metoda:**
> - testy lokalne w obrazie `projekt_inzynierski-admin-backend` (Python 3.11.17, **`cryptography` 50.0.2**,
>   **OpenSSL 3.5.7**, uvicorn 0.54.0, FastAPI 0.142.2), opisane w Załączniku A;
> - dokumentacja producentów, RFC i changelogi, z linkami w sekcji 6.
>
> **Założenie o łączu (aktualizacja 2026-10-21, zob. `AGENTS.md`):** P2P między węzłami symuluje **bardzo wolne
> łącze krótkiego zasięgu bez internetu** (np. radio między dwoma okrętami). Każdy zaoszczędzony bajt jest
> pożądany, nawet przy małych CRL. Zmienia to rekomendację dotyczącą delta-CRL (pkt 4 streszczenia, sekcje 3 i 5/D1).
>
> **Legenda wiarygodności** (stosowana w tabelach):
> - **[Z]** zweryfikowane lokalnie (uruchomiony kod lub `--help` w obrazie projektu);
> - **[D]** potwierdzone w dokumentacji, RFC lub changelogu (link w sekcji 6);
> - **[P]** przypuszczenie albo wiedza ogólna, niezweryfikowana w tej sesji. Przed cytowaniem w pracy sprawdź.

---

## 1. Streszczenie – rekomendowany zestaw

1. **Kryptografia: zostać przy `pyca/cryptography` (≥ 45, w obrazie jest 50.0.2).** Biblioteka buduje i parsuje
   wszystko, czego potrzebuje projekt: `CRLNumber`, `DeltaCRLIndicator`, `FreshestCRL`,
   `IssuingDistributionPoint`, AKI/SKI, `KeyUsage`, CSR, PKCS#12 z AES-256, odpowiedzi OCSP [Z].
   Nie trzeba dokładać pyOpenSSL ani asn1crypto.
2. **Weryfikacja łańcucha: `cryptography.x509.verification` (`PolicyBuilder` → `ClientVerifier`).** API jest stabilne
   od 50.0.0 [D]. Pozwala podać czas weryfikacji (`.time()`), co ułatwia testy rozjazdu zegara.
   **Nie sprawdza jednak CRL ani OCSP**: `Store` przyjmuje tylko certyfikaty [Z], a obsługa CRL jest otwartym
   tematem w issue #10034 [D]. Sprawdzanie CRL i polityka świeżości to więc własny, cienki kod na węźle (#30, #39).
   Jest to raczej zaleta, bo właśnie ta logika jest przedmiotem pracy.
3. **Najpierw dopisać AKI/SKI/KeyUsage w CA (#22).** Certyfikat w kształcie, jaki dziś wydaje `ca.py`, jest
   **odrzucany** przez `ClientVerifier` z domyślną polityką: brakuje rozszerzenia 2.5.29.35 (AKI) [Z].
4. **Status odwołania: pełna CRL z `CRLNumber` jako mechanizm podstawowy, a skumulowane delta-CRL jako
   optymalizacja transferu P2P** (zmiana względem docs §8, zob. `AGENTS.md`). Pełna CRL to ok. 0,2 KB + ~39 B
   na wpis (EC P-256) [Z], np. 100 odwołań ≈ 4 KB, a delta z jednym wpisem ≈ 0,2 KB [Z]. Na bardzo wolnym łączu
   ta różnica się liczy. Wariant zgodny z RFC 5280 §5.2.4 działa tak:
   - CA podpisuje delty kumulatywne do K ostatnich baz;
   - węzeł na podstawie rozmiarów z `summary` pobiera **jeden** obiekt: pasującą deltę albo pełną CRL.

   Delty mają ostre krawędzie: OpenSSL **bez `-use_deltas` po cichu je ignoruje i akceptuje odwołany certyfikat**
   [Z], więc weryfikator musi obsługiwać je jawnie (#32, #29).
5. **OCSP: tylko teoria, ewentualnie mały eksperyment z odpowiedzią „pre-produced”.** Klasyczny OCSP wymaga
   łączności z responderem. Wariant offline (RFC 5019, wcześniej podpisane odpowiedzi bez nonce) da się zbudować
   w `cryptography` [Z]. Wymaga jednak osobnej odpowiedzi dla każdego certyfikatu i nie ma monotonicznego numeru
   jak `CRLNumber`. Branża też odchodzi od OCSP: Let's Encrypt wyłączył go 2025-08-06 [D].
6. **Dystrybucja: własny gossip anti-entropy na FastAPI + `httpx` + `asyncio`** wg docs §4. Gotowe biblioteki
   nie są warte swojej złożoności: memberlist/Serf (Go, przynależność do klastra, a nie synchronizacja danych),
   py-libp2p (0.6.x, sama dokumentacja nazywa go niegotowym do produkcji [D]), DTN/Bundle Protocol (osobny demon).
   DTN i Syncthing najlepiej wykorzystać jako materiał porównawczy w rozdziale 3 (#15, #18, #28, #29, #31).
7. **Kanał WAN: pull inicjowany przez węzeł.** Łączność wystawia te same endpointy `/pki/summary` i `/pki/crl`
   co węzły, więc dla węzła jest po prostu „sąsiadem zawsze z najnowszymi danymi”. Jeden kod obsługuje oba kanały (#15, #16).
8. **Enrolment: CSR (PKCS#10) generowany na węźle.** CSR jest samopodpisany kluczem węzła, więc może przejść przez
   niezaufanych pośredników, podobnie jak certyfikat wracający w drugą stronę. EST, SCEP i CMP warto opisać
   w teorii; ACME nie pasuje do pracy offline (#23, #26).
9. **Czas: polityka świeżości po stronie CA i po stronie węzła.** Po stronie CA: krótki okres publikacji
   z zakładką (overlap), jak w EJBCA czy AD CS. Po stronie węzła: konfigurowalny okres łaski z soft-fail
   i tolerancja rozjazdu zegara. Czas „teraz” wstrzykiwany do weryfikatora (#33, #34).
10. **Testy:** `openssl verify -crl_check [-use_deltas] -attime` jako niezależna wyrocznia [Z]. Do tego
    `docker network disconnect` (już używane w `client.sh`), `tc netem` lub Pumba do opóźnień i strat,
    pytest z wstrzykiwanym zegarem oraz libfaketime do testów całych kontenerów.

---

## 2. Tabele porównawcze per obszar

### 2.1 Biblioteki kryptograficzne / PKI dla Pythona (#22, #23, #30, #32, #39)

**Funkcje `pyca/cryptography` potrzebne w projekcie** (wszystkie sprawdzone w 50.0.2):

| Funkcja | API w `cryptography` | Od wersji | Uwagi |
|---|---|---|---|
| Budowa i parsowanie CRL | `x509.CertificateRevocationListBuilder`, `CertificateRevocationList.is_signature_valid(pubkey)`, `get_revoked_certificate_by_serial_number` | dawno (<35); `next_update_utc`/`last_update_utc` od 42 [P] | [Z] Wynik `is_signature_valid` trzeba sprawdzać jawnie, metoda nie rzuca wyjątku. |
| `CRLNumber` (RFC 5280 §5.2.3) | `x509.CRLNumber(n)` | dawno [P] | [Z] |
| `DeltaCRLIndicator` (§5.2.4) | `x509.DeltaCRLIndicator(base_number)`, critical=True | dawno [P] | [Z] Zbudowana delta jest poprawnie konsumowana przez OpenSSL (`-use_deltas`). |
| `FreshestCRL` (§5.2.6 / §4.2.1.15) | `x509.FreshestCRL([DistributionPoint…])` | dawno [P] | [Z] |
| `IssuingDistributionPoint` (§5.2.5) | `x509.IssuingDistributionPoint(...)` | dawno [P] | [Z] Obecność klasy sprawdzona, budowy nie testowano. |
| AKI / SKI (§4.2.1.1–2) | `AuthorityKeyIdentifier.from_issuer_public_key()`, `SubjectKeyIdentifier.from_public_key()` | dawno [P] | [Z] **Wymagane przez `ClientVerifier` z domyślną polityką** (#22). |
| `KeyUsage` (`keyCertSign`, `cRLSign`) | `x509.KeyUsage(...)` | dawno | [Z] Docs §4 (krok 2) wymaga sprawdzenia, czy cert CA ma `cRLSign`. |
| Weryfikacja łańcucha | `x509.verification.PolicyBuilder().store(Store([ca])).time(t).build_client_verifier().verify(leaf, intermediates)` | 42.0 (serwer), **43.0 `ClientVerifier`**, 45.0 `ExtensionPolicy`, **50.0 API stabilne** [D] | [Z] **Bez CRL/OCSP.** `Store` przyjmuje tylko certyfikaty. Wymaga AKI w EE; `permit_all()` dla CA nie przejdzie bez wymagania `basicConstraints` [Z]. |
| Weryfikacja pojedynczego ogniwa | `Certificate.verify_directly_issued_by(issuer)` | 40.0 [D] | [Z] Działa także na obecnych certyfikatach bez AKI. Przydaje się jako „plan B” lub do weryfikacji samej CRL. |
| CSR (PKCS#10) | `CertificateSigningRequestBuilder`, `csr.is_signature_valid` | dawno | [Z] |
| PKCS#12 | `pkcs12.serialize_key_and_certificates(...)`, `PBES.PBESv2SHA256AndAES256CBC` przez `PrivateFormat.PKCS12.encryption_builder()` | `encryption_builder` od 38.0 [D] | [Z] Plik z kluczem, certyfikatem i CA ≈ 1,5 KB. |
| OCSP – budowa żądania i odpowiedzi | `ocsp.OCSPRequestBuilder`, `ocsp.OCSPResponseBuilder.add_response(...).responder_id(...).sign(...)` | OCSP od 2.4 [P]; `add_response_by_hash` 45.0 [D] | [Z] Odpowiedź ≈ 262 B (EC P-256), żądanie ≈ 68 B. |
| OCSP – **weryfikacja** odpowiedzi | brak metody; ręcznie: `issuer_pub.verify(resp.signature, resp.tbs_response_bytes, …)` | – | [Z] `OCSPResponse` nie ma metody `verify`/`is_signature_valid`. Delegowanego respondera trzeba sprawdzić samemu. |
| CMS/PKCS#7 – podpis | `pkcs7.PKCS7SignatureBuilder` | dawno; PSS od 42.0 [D] | [Z] W module są tylko podpis, szyfrowanie i deszyfrowanie. **Brak weryfikacji podpisu PKCS#7** [Z]. |

**Porównanie bibliotek:**

| Biblioteka | Łańcuch | CRL w weryfikacji | Delta-CRL | OCSP | Utrzymanie / licencja | Ocena dla projektu |
|---|---|---|---|---|---|---|
| **pyca/cryptography** 50.0.2 | tak (`verification`) [Z] | **nie** [Z][D] | budowa i parsowanie [Z] | budowa i parsowanie, bez weryfikacji [Z] | bardzo aktywna; Apache-2.0/BSD [D] | **Rekomendowana.** Już w `requirements.txt` admina i edges; CRL i świeżość dopisać samemu. |
| **pyOpenSSL** (24.3+ / 26.x) | `X509Store` + `X509StoreContext` (OpenSSL) | tak, przez `X509Store.add_crl` (przyjmuje CRL z `cryptography` od 24.1) [D] | flagi OpenSSL [P] | nie | klasy CRL usunięte w 24.3.0; 26.3.0 zapowiada wycofanie całego `X509` [D] | **Nie.** Biblioteka jest wygaszana. |
| **asn1crypto** | – (tylko parsowanie i budowa ASN.1) | – | parsowanie | parsowanie | ograniczone utrzymanie [P]; MIT | Nie jest potrzebna, `cryptography` pokrywa parsowanie. |
| **certvalidator** (wbond) | tak | tak | tak [P] | tak | praktycznie porzucony [P] | Nie. |
| **pyhanko-certvalidator** (fork) | tak (RFC 5280 §6) | **tak**, tryby `soft-fail` / `hard-fail` / `require` [D] | **tak**, także indirect CRL [D] | tak, z delegowanym responderem [D] | aktywny (~0.30–0.32) [D]; MIT [P] | **Alternatywa** albo niezależna druga implementacja do testów krzyżowych. Wadą jest zależność od asn1crypto i model „fetch z sieci”, który przy pracy offline trzeba zastąpić podawaniem CRL ręcznie [P]. |
| **OpenSSL CLI** 3.5.7 | `openssl verify` | `-crl_check`, `-crl_check_all` [Z] | `-use_deltas` [Z] | `openssl ocsp` (responder, `-ndays`, `-respout`, `-validity_period`, `-status_age`) [Z] | Apache-2.0 | **Wyrocznia w testach**, nie do kodu usług. |

### 2.2 Mechanizmy statusu odwołania (#29, #32, #33)

Rozmiary zmierzono w Załączniku A dla podpisu EC P-256. Obecne CA używa RSA-4096, co dodaje ok. 440 B
na podpis (512 B zamiast ~72 B) [P – wyliczenie].

| Mechanizm | Działa offline | Rozmiar danych | Świeżość | Odporność na rollback / freeze | Złożoność implementacji | Wsparcie w narzędziach |
|---|---|---|---|---|---|---|
| **Pełna CRL** (RFC 5280 §5) | **tak**: jeden podpisany obiekt na CA, weryfikacja lokalna | ~170 B + ~39 B na wpis [Z] (0 → 169 B, 100 → 4 KB, 1000 → 39 KB) | do `nextUpdate`; o świeżości decyduje polityka publikacji | rollback: **tak**, przez monotoniczny `CRLNumber` (§5.2.3). Freeze: ograniczony do `nextUpdate` | **niska** | wszędzie: OpenSSL, EJBCA, Dogtag, Vault, step-ca (eksperymentalnie), CFSSL, Windows [D] |
| **Delta-CRL** (§5.2.4, §5.2.6) | tak, ale **wymaga posiadania bazy** z `CRLNumber ≥ BaseCRLNumber` | ~200 B + ~39 B na wpis od bazy [Z] | krótszy cykl delt przy rzadkiej bazie | jak CRL (wspólna numeracja baz i delt, §5.2.3) | **średnia**: łączenie baza+delta, `removeFromCRL`, dwa harmonogramy | generowanie: EJBCA, Dogtag, Vault ≥1.12 [D], `cryptography` [Z]; **nie** `openssl ca` [D]. Konsumpcja: OpenSSL `-use_deltas` [Z], pyhanko [D], Windows [P]; BoringSSL usunął obsługę [D] |
| **OCSP klasyczny** (RFC 6960) | **nie**: zapytanie do respondera przy każdej weryfikacji (lub cache) | żądanie ~68 B, odpowiedź ~262 B [Z] | „na żywo” | z nonce (§4.4.1, RFC 8954) chroni przed replay, ale wymaga łączności | średnia (responder + baza statusów) | OpenSSL `ocsp`, EJBCA, Dogtag, Vault (bez nonce) [D], CFSSL; step-ca nie ma [D] |
| **OCSP pre-produced** (RFC 5019, RFC 6960 §2.4) | **tak**: odpowiedzi podpisane z góry, rozsyłane jak CRL | ~262 B **na każdy certyfikat** [Z] | do `nextUpdate` odpowiedzi | **brak monotonicznego numeru**: porównanie tylko `producedAt`/`thisUpdate`. Freeze do `nextUpdate` | średnia: N odpowiedzi, odświeżanie, ręczna weryfikacja w `cryptography` [Z] | EJBCA (Enterprise) [D], CFSSL `ocspsign`/`ocsprefresh` [D], OpenSSL `ocsp -respout` [Z] |
| **OCSP stapling / Must-Staple** (RFC 6066 §8, RFC 6961, RFC 7633) | częściowo: dowód statusu dostarcza strona prezentująca certyfikat | jak pre-produced | jak pre-produced | jak pre-produced; Must-Staple wymusza obecność dowodu | wymaga TLS między stronami | serwery TLS; Let's Encrypt wycofał Must-Staple w 2025 [D] |
| **Certyfikaty krótkożyjące** | tak: brak danych o odwołaniu, wygasanie zastępuje odwołanie | 0 | okres ważności (CA/B: ≤ 7 dni od 2026-03-15 [D]) | n/d. Węzeł odcięty dłużej niż ważność traci certyfikat | niska po stronie RP, wysoka po stronie odnowień (wymagają łączności!) | step-ca (pasywne odwołanie) [D], ACME |
| **CRLite / CRLSets** | tak: filtry pushowane do klienta | CRLite: skompresowane filtry całej populacji [P]; CRLSets: mały podzbiór [P] | aktualizacje push | zależy od kanału aktualizacji | wysoka (CRLite) | Firefox / Chrome, tylko WebPKI [P] |
| **Certificate Transparency** (RFC 6962/9162) | n/d: nie jest mechanizmem odwołania | – | – | – | – | tylko tło (wykrywanie błędnych wystawień) |

**Rekomendacja:** pełna CRL z `CRLNumber`, AKI i rozsądnym `nextUpdate` jako podstawa. Do tego **adaptacyjnie
wybierane skumulowane delta-CRL** jako optymalizacja wolnego łącza P2P (sekcja 3a). OCSP pre-produced tylko jako
pomiar i opis (szczegóły w sekcjach 3 i 5).

### 2.3 Gotowe systemy CA (#10, #23)

| System | Delta-CRL | OCSP | Pre-signed OCSP | `CRLNumber` | Root offline + Issuing CA | Enrolment | Licencja | Rola w projekcie |
|---|---|---|---|---|---|---|---|---|
| **OpenSSL** `ca`/`crl`/`ocsp` 3.5 | **nie generuje** („V2 CRL features like delta CRLs are not currently supported”) [D]; konsumuje (`-use_deltas`) [Z] | `openssl ocsp` (responder testowy, plik `index`) [Z] | `-respout` + `-ndays`/`-nmin` [Z] | plik `crlnumber` (hex) [D] | ręcznie, dwie konfiguracje | `openssl cmp` (klient CMP od 3.0, mock serwer w buildach bez NDEBUG) [D] | Apache-2.0 | wyrocznia w testach; porównanie |
| **EJBCA CE / Enterprise** (Keyfactor) | tak („Delta CRL Period > 0”) [D] | tak (VA) | **Enterprise only** („OCSP Response Pre-Production”, od 7.4) [D] | tak, wszystkie CRL zapisywane w bazie [D] | tak (typowe wdrożenie) [P] | CMP, EST, SCEP, ACME [P – podział CE/EE niepotwierdzony] | LGPL-2.1 (CE) [P] / komercyjna | materiał porównawczy (rozdz. 2). „CRL overlap”, „CRL Updater Service” to wzorce dla polityki świeżości |
| **Dogtag PKI** (Red Hat) | tak („Generate full CRL every N deltas”) [D] | tak (OCSP subsystem) [P] | [P] | tak (`pki_ca_starting_crl_number`) [D] | tak [P] | SCEP, (EST/ACME w nowszych) [P] | GPL [P] | porównanie: podsystemy CA/OCSP/KRA jako analogia do podziału Panel/Łączność |
| **step-ca** (smallstep) | nie [D – brak w docs] | **nie** [D – brak w docs] | nie | tak (CRL od v0.23.0, „experimental”) [D] | tak (root + intermediate z `step ca init`) [P] | ACME, OIDC, JWK, SCEP [P] | Apache-2.0 [P] | porównanie: **pasywne odwołanie** + krótkożyjące certyfikaty jako przeciwny biegun |
| **CFSSL** (Cloudflare) | nie [P] | `ocspserve` | **tak**: `ocspsign` / `ocsprefresh` / `ocspdump` → `ocspserve` [D] | `gencrl` [D – bez szczegółów] | tak [P] | API własne | BSD-2 [P] | porównanie: modelowy przykład **OCSP pre-signed** |
| **HashiCorp Vault PKI** | **tak** (od 1.12; `/pki/crl/delta`) [D] | tak (od 1.12; „bez rozszerzeń RFC”, **bez nonce**) [D] | odpowiedzi generowane na żądanie [P] | tak (CRL v2 od 1.11) [D] | tak (wiele issuerów w mount) [D] | ACME (1.14+) [P], EST/CMP (Enterprise) [P] | BUSL-1.1 od 2023 [P] | porównanie: `auto_rebuild`, `If-Modified-Since` / 304 przy CRL [D] |
| **XCA** | nie [P] | nie | nie | tak [P] | tak (GUI) | brak (pliki) | BSD [P] | tylko wspomnienie. Model „CA offline na laptopie” jest bliski idei Root offline |

**Wniosek:** żaden gotowy system nie ma wbudowanej **dystrybucji P2P store-and-forward**. Wszystkie zakładają
publikację pod URL (CDP/AIA) albo do LDAP. To uzasadnia własny komponent Łączność i gossip na węzłach.
Integrowanie któregoś z nich z obecnym backendem (np. zastąpienie `ca.py` przez step-ca lub Vault) nie zamyka żadnej
luki z audytu, a dokłada ciężką zależność. Rekomendacja: wszystkie traktować jako **materiał porównawczy**.

### 2.4 Dystrybucja przy przerywanej łączności (#15, #18, #28, #29, #31)

| Rozwiązanie | Model | Store-and-forward | Integracja z Python/FastAPI | Licencja / dojrzałość | Ocena |
|---|---|---|---|---|---|
| **Własny gossip (docs §4)**: FastAPI + `httpx.AsyncClient` + zadanie `asyncio` w `lifespan` | pull anti-entropy na podpisanych obiektach; stan typu „max-register” po `CRLNumber` | tak: każdy węzeł trzyma najnowszą zweryfikowaną CRL i oddaje ją dalej | natywna, ~200–400 linii [P] | – | **Rekomendowane.** Pośrednik nie musi być zaufany. Zbieżność wynika z tego, że `max(CRLNumber)` jest łączne, przemienne i idempotentne (semikrata, jak w CRDT): kolejność i duplikaty nie mają znaczenia. |
| **HashiCorp memberlist / Serf** | SWIM: przynależność i wykrywanie awarii + rozgłaszanie zdarzeń [P] | nie (zdarzenia ulotne) [P] | brak bibliotek Python; osobny agent Serf + RPC [P] | Go; MPL-2.0 [P – sprawdzić, czy nie BUSL] | Nie. Rozwiązuje inny problem (membership); przy 2–3 węzłach ze stałymi IP zbędne. |
| **libp2p / py-libp2p** | transporty, PubSub (GossipSub), DHT | GossipSub z historią wiadomości [P] | py-libp2p 0.6.0 (2026-02-16); README: „zmierza ku produkcji”, docs: „not yet ready for production” [D] | MIT/Apache [P] | Nie. Dużo złożoności (peer ID, multiaddr, własne transporty) bez zysku przy sieci Docker. |
| **DTN: Bundle Protocol v7 (RFC 9171) + BPSec (RFC 9172)** – µD3TN, dtn7-go, dtn7-rs | store-carry-forward, custody, TTL wiązek | **tak, natywnie** | pyD3TN (klient µD3TN) [D]; dtn7-go: GPL-3.0 [D] | aktywne, niszowe | Nie do implementacji (osobny demon, warstwa sieciowa). **Świetne do części teoretycznej**: najbliższy standard dla „odbiorcy poza zasięgiem przez kilka dni”. |
| **Syncthing (BEP) / rsync** | synchronizacja plików, wektory wersji / delta transfer | Syncthing: tak, przez dowolnych peerów [P] | zewnętrzny proces | MPL-2.0 / GPL-3.0 [P] | Nie. Synchronizacja plików nie zna semantyki `CRLNumber` i podpisu, więc rozwiązywałaby konflikty, których w modelu jednego wystawcy nie ma. Tylko do porównania. |

Elementy własnej implementacji (wszystkie oparte na zależnościach, które projekt już ma):

- `httpx` (async, timeouty) zamiast `requests` w `edge_app/`;
- zadanie okresowe w `lifespan` FastAPI;
- atomowy zapis pliku (`os.replace`) na wolumenie Dockera;
- `If-None-Match` / ETag lub porównanie `crl_number` w `/pki/summary`, żeby nie pobierać tej samej CRL;
- limit rozmiaru ciała żądania (ochrona przed zaśmiecaniem węzła, #36).

### 2.5 Enrolment i dystrybucja klucza (#23, #26, #35)

| Protokół | Standard | Wymaga łączności w czasie rzeczywistym? | Możliwość store-and-forward | Python | Ocena |
|---|---|---|---|---|---|
| **CSR (PKCS#10) + własne API** | RFC 2986 | nie: CSR jest samopodpisany (proof-of-possession), certyfikat jest podpisany przez CA | **tak**: oba obiekty są samoweryfikowalne, więc mogą iść przez pośredników | `cryptography` [Z] | **Rekomendowane.** Klucz prywatny nigdy nie opuszcza węzła. |
| **Zaszyfrowany PKCS#12** | RFC 7292 | nie | tak, ale **poufność zależy wyłącznie od hasła**, które trzeba dostarczyć innym kanałem | `cryptography`, PBES2/AES-256 [Z] | Tylko jako fallback, gdy węzeł nie ma generatora entropii lub HSM. |
| **EST** | RFC 7030 | tak (HTTPS + TLS, `/simpleenroll`); jest odpowiedź 202 + `Retry-After` [P] | słabo: protokół jest wiązany z sesją TLS [P] | brak dojrzałej biblioteki Python (nie znaleziono) [D – wynik wyszukiwania]; libest (C) [P] | Teoria. |
| **SCEP** | RFC 8894 | tak, ale z trybem PENDING i odpytywaniem (`CertPoll`) [P] | częściowo: komunikaty to CMS, więc można je przenieść [P] | PyScep 0.0.14 (2022, „for testing”) [D] | Teoria; słabe hasło challenge i przestarzała kryptografia jako argument przeciw. |
| **CMP** | RFC 4210 → **RFC 9480** (aktualizacje), **RFC 9483** (Lightweight CMP Profile) | nie musi: komunikaty są samodzielnie chronione, a protokół przewiduje opóźnione dostarczenie i transport inny niż HTTP [P – sprawdzić RFC 9483 §6] | **tak (koncepcyjnie najlepiej pasuje)** [P] | `openssl cmp` (od 3.0) [D]; brak biblioteki Python [P] | Teoria. CMP to standardowy odpowiednik „CSR przez P2P”, dobry argument w rozdziale 2. |
| **ACME** | RFC 8555 | **tak**: walidacja wyzwania (http-01/dns-01) wymaga osiągalności | nie | wiele klientów | Nie pasuje do pracy offline; wymienić jako kontrast. |

### 2.6 Czas i świeżość (#33, #34)

| Element | Zachowanie w istniejących systemach | Źródło | Wniosek dla projektu |
|---|---|---|---|
| `nextUpdate` przekroczony | OpenSSL: **twardy błąd** `error 12 … CRL has expired`; okresu łaski brak, jest tylko `-attime` lub `-no_check_time` [Z] | Zał. A | Okres łaski musi być własną logiką węzła. |
| Windows CryptoAPI | `NextUpdate` = moment wygaśnięcia CRL/OCSP; kolejność: staple → cache URL → magazyn systemowy → sieć; rozszerzenie *Next CRL Publish* (1.3.6.1.4.1.311.21.4) do wcześniejszego pobierania [D]. Brak ważnej CRL daje status „revocation offline/unknown”, a decyzję podejmuje aplikacja [P] | MS Learn | Analogia: węzeł zwraca **trójstanowy** wynik (`valid` / `revoked` / `unknown-stale`), a polityka decyduje. |
| AD CS / EJBCA – overlap | AD CS: zakładka domyślnie 10% okresu ważności CRL [D]. EJBCA: CRL Updater wydaje nową CRL przed `nextUpdate − overlap`; zalecenie „lepiej wcześniej niż później” [D] | TechNet, Keyfactor | Po stronie CA: publikacja co `P`, `nextUpdate = now + P + overlap`, gdzie overlap ≥ typowy czas propagacji P2P. |
| Przeglądarki | OCSP w trybie soft-fail [P]; Chrome: CRLSets, Firefox: CRLite [P] | – | Kontrast: WebPKI świadomie wybiera soft-fail, systemy krytyczne – hard-fail. |
| pyhanko-certvalidator | `revocation_mode`: `soft-fail` (domyślny), `hard-fail`, `require` [D] | changelog | Gotowa nomenklatura do przejęcia w polityce węzła. |
| Rozjazd zegara | RFC 5280 nie definiuje tolerancji [P]. OpenSSL `ocsp -validity_period` (tolerancja dla OCSP) i `-status_age` [Z]; dla CRL brak odpowiednika [Z] | Zał. A | Tolerancja `skew` jako parametr węzła (docs §4 krok 4). |
| Synchronizacja zegara | NTP (RFC 5905), NTS (RFC 8915, uwierzytelniony NTP) [P]; **Roughtime** zatwierdzony przez IESG jako Experimental RFC (2026-03-17), numer RFC niepotwierdzony [D]. Cel Roughtime: czas „wystarczający do walidacji certyfikatów” (±10 s) [D] | IETF datatracker | Węzeł offline **nie ma** źródła czasu, więc trzeba przyjąć dryf zegara RTC. Heurystyka: `now_trusted ≥ max(thisUpdate widzianych CRL)` (czas nie może się cofnąć poniżej najnowszego podpisanego znacznika). |

### 2.7 Uwierzytelnianie P2P (#36)

| Opcja | Co daje | Koszt | Ocena |
|---|---|---|---|
| **Brak (stan docelowy wg docs §8)** + weryfikacja przed użyciem | integralność i autentyczność CRL/certyfikatów wynika z podpisu CA; kolejność z `CRLNumber` | 0 | **Wystarczające dla danych PKI.** Pozostaje DoS i spam: limity rozmiaru, rate limit, odrzucanie przed zapisem na dysk. |
| **mTLS** (uvicorn `--ssl-certfile/--ssl-keyfile/--ssl-ca-certs/--ssl-cert-reqs` [Z]; klient `httpx` z `cert=`/`verify=`) | poufność, uwierzytelnienie peera certyfikatem węzła z tego samego CA | średni: certyfikaty węzłów (wymaga enrolmentu, #23), rotacja, sprawdzanie CRL **także dla TLS** (uvicorn/ssl nie zrobi tego za nas). Dostęp do certyfikatu peera w FastAPI nie jest standardowy [P] | Opcjonalne. Problem „jajka i kury”: węzeł bez aktualnej CRL nie może sprawdzić, czy peer nie został odwołany. |
| **Podpis obiektu** (CMS/PKCS#7 RFC 5652, JWS RFC 7515, COSE RFC 9052) kluczem węzła | niezaprzeczalność nadawcy wiadomości (np. `summary`) | niski–średni; `cryptography` podpisuje CMS, ale **nie weryfikuje** go [Z]; JWS: `joserfc`/`jwcrypto` [P]; COSE: `pycose` [P] | Niepotrzebne dla CRL (już podpisana). Ma sens tylko dla wiadomości nie-PKI (czat, pliki). |

### 2.8 Narzędzia testowe (docs §6)

| Narzędzie | Do czego | Integracja | Uwagi |
|---|---|---|---|
| `docker network disconnect/connect` | odcięcie WAN (scenariusze 1, 2, 5) | już w `edge_app/client.sh` | najprostsze i deterministyczne |
| `tc qdisc … netem` | opóźnienie, utrata, ograniczenie pasma na interfejsie kontenera | wymaga `cap_add: NET_ADMIN` lub `nsenter` z hosta [P] | metryka „narzut transferu” przy wąskim łączu |
| **Pumba** | netem/stop/pause dla kontenerów z CLI | osobny kontener z `docker.sock` [P]; Apache-2.0 [P] | wygodne skryptowanie scenariuszy |
| **toxiproxy** (Shopify) | proxy TCP z „toksynami” (latency, timeout, bandwidth, reset) | jako kontener między węzłami [P]; MIT [P] | test zerwań w połowie transferu (atomowość zapisu) |
| **Wstrzykiwany zegar** (parametr `now` w weryfikatorze, `PolicyBuilder.time()` [Z]) | rozjazd zegara, przeterminowanie (scenariusze 2, 4) | pytest | **Preferowane:** zero magii, testy deterministyczne |
| `time-machine` / `freezegun` | przesuwanie czasu w Pythonie | pytest [P]; MIT / Apache-2.0 [P] | nie wpływają na czas w kodzie Rust/C (np. domyślny czas `PolicyBuilder` czy OpenSSL) [P], więc lepiej jawnie podawać `now` |
| **libfaketime** | przesunięcie zegara całego procesu lub kontenera (`LD_PRELOAD`, `FAKETIME`) | ENV w Dockerfile [P]; GPL-2.0 [P] | test end-to-end „węzeł z zegarem +3 dni”; działa dla Pythona i OpenSSL (dynamiczne linkowanie) [P] |
| `openssl verify -crl_check[_all] [-use_deltas] -attime T` | niezależna wyrocznia decyzji weryfikatora | [Z] | porównanie decyzji „nasz weryfikator vs OpenSSL” jako metryka „odsetek poprawnych decyzji” |
| pytest + `httpx.ASGITransport` | testy endpointów `/pki/*` bez sieci | [P] | testy jednostkowe protokołu gossip (złośliwy pośrednik, scenariusz 3) |

---

## 3. OCSP vs CRL vs delta-CRL w środowisku o ograniczonej łączności

*(Tekst do adaptacji w rozdziale 2/3 pracy.)*

**Wspólny problem.** Każdy mechanizm statusu odwołania odpowiada na pytanie „czy w chwili *t* certyfikat
o numerze *s* był odwołany?”. Różni je to, *kto* i *kiedy* tę odpowiedź podpisuje oraz *ile* danych relying party
musi mieć lokalnie. W systemie z przerywaną łącznością decydujące są trzy cechy:
(1) czy dowód statusu da się zweryfikować bez kontaktu z CA,
(2) czy dowód może przejść przez niezaufanego pośrednika,
(3) jak węzeł ocenia jego aktualność, gdy nie zna dokładnego czasu.

**Pełna CRL (RFC 5280 §5).** CRL to jeden obiekt podpisany przez CA, zawierający listę numerów seryjnych
odwołanych certyfikatów oraz pola `thisUpdate`/`nextUpdate`. Weryfikacja wymaga tylko certyfikatu CA (trust anchor)
i zegara. Pośrednik nie może jej zmodyfikować bez unieważnienia podpisu. Może natomiast podać **starszą**,
poprawnie podpisaną CRL (atak rollback). Przeciwdziała temu rozszerzenie `CRLNumber` (§5.2.3): monotonicznie rosnący
numer, wspólny dla CRL pełnych i delt. Węzeł akceptuje tylko numer większy od posiadanego.
Pozostaje atak *freeze*: pośrednik wstrzymuje nowe CRL. Ogranicza go `nextUpdate`, po którym węzeł uznaje dane
za nieaktualne. Rozmiar rośnie liniowo z liczbą odwołań (pomiar: ~39 B na wpis), ale nie zależy od liczby
wszystkich certyfikatów. Przy kilkudziesięciu–kilkuset odwołaniach to pojedyncze kilobajty, mniej niż jeden
obraz na stronie WWW.

**Delta-CRL (RFC 5280 §5.2.4, §5.2.6).** Delta-CRL zawiera tylko zmiany względem wskazanej bazy.
Rozszerzenie krytyczne `DeltaCRLIndicator` niesie `BaseCRLNumber` = *M*. Deltę można połączyć z dowolną pełną CRL
o numerze ≥ *M* i mniejszym od numeru delty. Typowo (EJBCA, Vault, Dogtag) delty są **kumulatywne**
względem ostatniej bazy, więc węzeł, który przegapił kilka delt, potrzebuje tylko najnowszej delty i właściwej bazy.
Węzeł, który **nie ma** bazy o numerze ≥ *M*, nie może użyć delty i musi najpierw pobrać pełną CRL. Dla odciętego
węzła oznacza to, że po zmianie bazy delta jest bezużyteczna, dopóki nie dotrze nowa baza. Pełna CRL jest więc
nadal potrzebna i delta jej nie zastępuje. Zysk transferowy liczymy jako różnicę
`~39·N_wszystkich` vs `~39·N_od_bazy`. Ma znaczenie przy tysiącach wpisów i częstych odświeżeniach (pasmo
satelitarne, radio), a znika przy małych CRL. Pomiar w projekcie pokazał ryzyko implementacyjne:
`openssl verify -crl_check` bez flagi `-use_deltas` **ignoruje deltę i akceptuje odwołany certyfikat**,
a BoringSSL całkowicie usunął obsługę delt. Weryfikator, który nie obsługuje delt jawnie, daje więc fałszywą
akceptację (fail-open). To mocny argument za ostrożnością.

**OCSP (RFC 6960, profil RFC 5019).** OCSP zastępuje listę odpowiedzią o pojedynczym certyfikacie, podpisaną
przez CA lub delegowany responder (certyfikat z EKU `id-kp-OCSPSigning`, zwykle z `id-pkix-ocsp-nocheck`, §4.2.2.2).
W klasycznym trybie klient pyta respondera online, opcjonalnie z *nonce* (§4.4.1, RFC 8954) chroniącym
przed powtórzeniem. Nonce czyni odpowiedź unikalną dla jednego zapytania, więc **wyklucza cache'owanie
i przekazywanie** przez pośredników. W środowisku bez łączności klasyczny OCSP nie działa.
Adaptacja polega na rezygnacji z nonce i użyciu **odpowiedzi wstępnie wygenerowanych** (*pre-produced*, RFC 5019;
pola `thisUpdate`/`nextUpdate`, §2.4). CA albo responder co okres podpisuje odpowiedź dla każdego ważnego certyfikatu,
a odpowiedzi rozchodzą się jak CRL (P2P) albo są dołączane przez właściciela certyfikatu (*stapling*, RFC 6066 §8;
*Must-Staple*, RFC 7633). Taki dowód jest mały (~260 B), samodzielnie weryfikowalny i nie ujawnia CA, kto sprawdza
certyfikat. Wady w tym środowisku:

- (a) liczba obiektów rośnie z liczbą **wszystkich** certyfikatów, a nie odwołanych;
- (b) każdą odpowiedź trzeba regularnie odnawiać przed `nextUpdate`, co daje ruch nawet bez żadnych odwołań;
- (c) brak monotonicznego numeru. Odporność na rollback opiera się na porównaniu `producedAt`/`thisUpdate`,
  czyli na zegarze, który w węźle odciętym jest najmniej pewny;
- (d) okno *freeze* jest takie samo jak w CRL (do `nextUpdate`).

Tendencja w WebPKI jest odwrotna niż dawniej: CA/Browser Forum uczyniło OCSP opcjonalnym (SC-063, 2023),
a Let's Encrypt wyłączył responder (2025-08-06), wskazując CRL jako mechanizm prywatniejszy i tańszy.

**Certyfikaty krótkożyjące** usuwają problem statusu (wygasanie zastępuje odwołanie), ale przenoszą wymaganie
łączności na *odnowienie*. Węzeł odcięty dłużej niż okres ważności traci certyfikat. Pasują więc tylko wtedy,
gdy maksymalny czas odcięcia jest krótszy od okresu ważności.

**Wniosek dla systemu.** Dla populacji rzędu dziesiątek–setek certyfikatów i odcięć trwających dni podstawą jest
**pełna CRL z `CRLNumber`**. Do tego dochodzą:

- dystrybucja anti-entropy przez niezaufanych pośredników;
- polityka świeżości: overlap po stronie CA oraz okres łaski i trójstanowy wynik po stronie węzła.

Łącze P2P jest w tym systemie bardzo wąskie (transmisja krótkiego zasięgu, np. między okrętami). Dlatego
przyjęto **skumulowane delta-CRL wybierane adaptacyjnie** jako optymalizację transferu (sekcja 3a).
OCSP pre-produced pozostaje materiałem porównawczym. Jego koszt rośnie z liczbą *wszystkich* certyfikatów,
a nie tylko odwołanych, więc na wąskim łączu przegrywa z CRL.

### 3a. Adaptacyjna aktualizacja CRL skumulowanymi deltami (cel projektowy)

**Zasada.** Przy każdej publikacji CA podpisuje:
- pełną CRL o numerze *N*;
- delty kumulatywne „od *N−1*”, „od *N−2*”, …, „od *N−K*”. Każda zawiera **wszystkie** zmiany od swojej bazy
  (`DeltaCRLIndicator` = numer bazy, `CRLNumber` = *N*, wspólna numeracja, RFC 5280 §5.2.3).

Przykład: odwołania 23 (wersja 9), 42 (wersja 10), 77 (wersja 11). Przy publikacji wersji 11 powstają:

| Obiekt | Zawartość | Dla węzła z wersją |
|---|---|---|
| pełna CRL 11 | [5, 17, 23, 42, 77] | dowolną (fallback) |
| delta 11 „od 10” | [77] | 10 |
| delta 11 „od 9” | [42, 77] | 9 |
| delta 11 „od 8” | [23, 42, 77] | 8 |

**Protokół na łączu P2P:**

1. Węzeł A (wersja *m*) pobiera od sąsiada B tylko `summary`: numer i rozmiar pełnej CRL oraz listę
   `{number, base, size}` dostępnych delt.
2. A wybiera **jeden** obiekt o najmniejszym rozmiarze spośród: pełnej CRL *N* oraz delty *N* o bazie ≤ *m*
   (RFC 5280 §5.2.4 pozwala połączyć deltę o bazie *M* z pełną CRL o numerze ≥ *M*).
3. Po pobraniu A weryfikuje obiekt: podpis CA, issuer/AKI, `CRLNumber` > lokalny, `thisUpdate ≤ now + skew`.
   Pobieranie przerywa, jeśli obiekt przekracza zadeklarowany rozmiar.
4. A przechowuje **oryginały** (swoją podpisaną pełną CRL *m* i deltę *N*/baza *m*) i przekazuje dalej właśnie je.
   Węzeł C weryfikuje je samodzielnie.

**Dlaczego bez łańcucha delt (9→10→11).** Po nałożeniu pierwszej łatki węzeł miałby „wersję 10” złożoną samodzielnie,
bez podpisu CA. Kolejnej delty z bazą 10 nie wolno na nią nałożyć: standard wymaga pełnej CRL podpisanej przez CA.
Delta kumulatywna nakłada się bezpośrednio na posiadaną, podpisaną bazę.

**Fallback na pełną CRL:**
- węzeł jest starszy niż najstarsza baza z historii (*m* < *N−K*);
- pełna lista jest mniejsza od delty, np. po usunięciu wpisów dla wygasłych certyfikatów, gdy delta musi nieść
  `removeFromCRL`.

**Bezpieczeństwo.** Rozmiary w `summary` podaje niezaufany sąsiad, ale służą wyłącznie optymalizacji. Kłamstwo
kosztuje najwyżej zmarnowany transfer, który ogranicza limit rozmiaru. Poprawność zapewnia weryfikacja po pobraniu.
Status certyfikatu wynika z bazy i delty razem, a świeżość ocenia się po `nextUpdate` delty (krótszym).

**Koszt po stronie CA:** K dodatkowych podpisów na publikację. Przy K = 3–5 i małych listach to pomijalne.

**Wsparcie w narzędziach:**
- **Generowanie:** `cryptography` (`DeltaCRLIndicator`, `CRLNumber`) [Z]. EJBCA, Vault i Dogtag wydają delty
  tylko względem ostatniej bazy [D/P], więc wariant „do K baz” jest własnym rozszerzeniem w granicach RFC 5280.
- **Weryfikacja:** OpenSSL wyłącznie z `-use_deltas` [Z].
- **Analogia:** Debian APT PDiffs, czyli różnicowe łatki indeksu z regułą „pobierz pełny plik, jeśli łatki
  są większe” [P].

**Metryka:** łączna liczba bajtów w P2P dla strategii „zawsze pełna” vs „zawsze delta” vs „adaptacyjnie”,
w funkcji liczby odwołań, długości odcięcia węzła i K.

---

## 4. Mapowanie: luka → narzędzie/mechanizm → uzasadnienie → nakład

Nakład: **S** < 1 dzień, **M** 1–3 dni, **L** > 3 dni (szacunek [P]).

| Luka | Proponowane narzędzie / mechanizm | Uzasadnienie | Nakład |
|---|---|---|---|
| #22 (brak AKI/SKI/KeyUsage) | `cryptography`: `SubjectKeyIdentifier.from_public_key`, `AuthorityKeyIdentifier.from_issuer_public_key`, `KeyUsage(keyCertSign, cRLSign)` w CA; `digitalSignature` w EE; opcjonalnie `ExtendedKeyUsage(clientAuth)` | bez AKI `ClientVerifier` odrzuca certyfikat [Z]; docs §4 krok 2 | S (wymaga nowego Root CA lub reissue) |
| #32 (brak `CRLNumber`) | `x509.CRLNumber(n)` + `AuthorityKeyIdentifier` w CRL; numer z `SEQUENCE` PostgreSQL (luki w numeracji są dopuszczalne, ważna jest monotoniczność) | ochrona przed rollbackiem (RFC 5280 §5.2.3) | S |
| #24, #27, #14 (CRL podpisywana przy każdym `GET`, proxy do admina) | tabela `crls(crl_number PK, this_update, next_update, der)`; CA generuje przy odwołaniu i okresowo (zadanie w `lifespan`), Łączność tylko `SELECT` | wzorzec EJBCA „CRL Updater” + overlap [D]; bez tego `CRLNumber` rośnie przy każdym odczycie | M |
| #13, #40 (Łączność z prawami właściciela bazy) | rola PostgreSQL `GRANT SELECT` na `crls`, `certificates`, `ca_cert` | wymuszenie strzałki „SQL (READ)” na poziomie bazy | S |
| #15, #16 (brak kanału WAN; push vs pull) | wspólna sieć Docker (lub jeden compose); **pull przez węzeł** z `httpx` na te same `/pki/summary` i `/pki/crl` w Łączności | jeden kod dla WAN i P2P; węzeł sam wie, kiedy ma łączność | M |
| #25, #26, #35 (dystrybucja certu CA, certyfikatów, rollover) | `/pki/summary` z `ca_fingerprint` i `certs_version`; obiekty podpisane przez CA rozsyłane tym samym gossipem; rollover: nowy Root przesłany jako cross-cert lub „NewWithOld” (wzorzec z RFC 4210 §4.4) [P] | ten sam mechanizm co CRL (docs §4) | M (rollover: L) |
| #30, #39 (brak weryfikatora na węźle) | moduł `verifier.py` w `edge_app/`: `PolicyBuilder().store(Store([ca])).time(now)` → `ClientVerifier`, następnie własne sprawdzenie CRL (podpis `is_signature_valid`, issuer, AKI, `cRLSign`, `get_revoked_certificate_by_serial_number`) i polityka świeżości; testy krzyżowe z `openssl verify` | `cryptography` nie sprawdza CRL [Z][D] | M |
| #18, #28, #29 (gossip, store-and-forward) | własny anti-entropy wg docs §4: FastAPI + `httpx` + `asyncio`, zapis atomowy (`os.replace`) na wolumenie | biblioteki (memberlist, libp2p, DTN) nieadekwatne (tab. 2.4) | M |
| #31 (brak weryfikacji danych od pośrednika) | weryfikacja przed zapisem: podpis CA + `CRLNumber` > lokalny + `thisUpdate ≤ now + skew`; limit rozmiaru | integralność tylko z podpisu CA (CLAUDE.md) | S (w ramach #29) |
| #33 (polityka `nextUpdate`) | CA: `nextUpdate = now + P + overlap`; węzeł: wynik `valid` / `revoked` / `unknown-stale` + `grace` + tryb `soft-fail` / `hard-fail` (nazewnictwo jak w pyhanko) | wzorce AD CS / EJBCA [D]; OpenSSL nie ma okresu łaski [Z] | S–M |
| #34 (rozjazd zegara) | parametr `skew_tolerance`; monotoniczny „czas zaufany” `≥ max(thisUpdate)`; wstrzykiwany `now` | NTP/Roughtime niedostępne offline | S |
| #23 (klucz w JSON) | endpoint CSR (PKCS#10) w CA, węzeł generuje klucz lokalnie; fallback: PKCS#12 z `PBESv2SHA256AndAES256CBC` | klucz nie opuszcza węzła; CSR i cert samoweryfikowalne → mogą iść P2P | M |
| #36 (uwierzytelnianie P2P) | brak mTLS (opisane ograniczenie) + limity; opcjonalnie mTLS w uvicorn (`--ssl-cert-reqs 2`) po wdrożeniu #23 | integralność już z podpisu CA (tab. 2.7) | S (limity) / M (mTLS) |
| #10 (jeden poziom CA) | opis Root offline + Issuing CA; weryfikator od razu przyjmuje `intermediates` (API `verify(leaf, intermediates)` [Z]) | zero kosztu w kodzie weryfikatora, zgodne z docs §8 | S (opis) |
| #37 (skrypty demo podpisują kluczem CA) | certyfikat testowy wydawany przez API CA; skrypt tylko `openssl verify -crl_check` | zasada z CLAUDE.md | S |
| #29, #32, docs §6 – transfer na wolnym łączu P2P | skumulowane delta-CRL do K baz w CA (`DeltaCRLIndicator`); `summary` z rozmiarami; wybór „pełna vs delta” na węźle; testy `openssl verify -use_deltas`; metryka bajtów w trzech strategiach (sekcja 3a) | łącze P2P bardzo wolne (`AGENTS.md`), każdy bajt się liczy | M |

---

## 5. Decyzje do podjęcia (z rekomendacją)

| # | Decyzja | Opcje | Rekomendacja | Uzasadnienie |
|---|---|---|---|---|
| D1 | Delta-CRL | (a) wdrożyć w protokole, (b) tylko generować w CA i mierzyć, (c) tylko opisać | **(a) – podjęta 2026-10-21:** skumulowane delty do K baz, wybór adaptacyjny, pełna CRL jako fallback (sekcja 3a, `AGENTS.md`) | Łącze P2P symuluje bardzo wolną transmisję krótkiego zasięgu, więc zysk jest pożądany nawet przy małych listach. Ryzyko fail-open ogranicza jawna obsługa delt w weryfikatorze i testy z `-use_deltas` [Z]. Do ustalenia: wartość K. |
| D2 | OCSP | (a) responder, (b) eksperyment z jedną odpowiedzią pre-produced, (c) tylko teoria | **(c), opcjonalnie (b)** | Zgodne z docs §8. Na wąskim łączu OCSP przegrywa z CRL: ~262 B na *każdy* ważny certyfikat co okres, wobec ~39 B na odwołany. (b) to ~0,5 dnia: budowa + ręczna weryfikacja + pomiar rozmiaru. Daje konkretną liczbę do tabeli porównawczej. |
| D3 | Biblioteka weryfikatora | (a) `cryptography` + własna CRL, (b) pyhanko-certvalidator | **(a)**, (b) najwyżej w testach | Mniej zależności, pełna kontrola polityki świeżości. Logika CRL to rdzeń pracy i warto ją mieć jawnie. |
| D4 | Kierunek WAN | push z Łączności / pull przez węzeł | **pull** | Węzeł wie, kiedy ma łącze; Łączność nie musi znać adresów węzłów; ten sam kod co P2P. |
| D5 | Dystrybucja klucza | CSR / PKCS#12 | **CSR**, PKCS#12 jako opisany fallback | Klucz nie opuszcza węzła; CSR przechodzi przez pośredników. |
| D6 | mTLS w P2P | tak / nie | **nie** (opisane ograniczenie), limity rozmiaru i częstotliwości | Integralność daje podpis CA; mTLS wymaga najpierw #23 i sprawdzania CRL dla samego TLS. |
| D7 | Parametry świeżości | – | propozycja: publikacja CRL co 24 h, `nextUpdate` = 7 d (≥ maks. odcięcie), `grace` = 72 h soft-fail, potem hard-fail; `skew` = 5 min; w testach skalowane do minut | Wartości do uzasadnienia założonym maksymalnym czasem odcięcia („kilka dni” z tematu). |
| D8 | Root + Issuing CA | wdrożyć / opisać | **opisać**, weryfikator gotowy na pośrednie | Zgodne z docs §8, a koszt późniejszego wdrożenia jest niski. |
| D9 | Jeden czy dwa pliki compose | – | **jeden compose** (lub wspólna sieć zewnętrzna `internet_net` z Łącznością) | Warunek konieczny dla #15; `client.sh internet off` odcina wtedy właśnie kanał do Łączności. |
| D10 | Algorytm klucza CA | RSA-4096 / EC P-256 | rozważyć **EC P-256** przy reissue (#22) | Podpis ~72 B zamiast 512 B na każdej CRL i certyfikacie; przy CRL z małą liczbą wpisów to większość rozmiaru [P – wyliczenie]. |

---

## 6. Źródła

**Standardy:**
- RFC 5280 – X.509 PKI Certificate and CRL Profile (§4.2.1.1–2 AKI/SKI, §5.2.3 CRLNumber, §5.2.4 Delta CRL Indicator, §5.2.5 IDP, §5.2.6 Freshest CRL, §6 path validation): https://www.rfc-editor.org/rfc/rfc5280
- RFC 6960 – OCSP (§2.4 thisUpdate/nextUpdate, §4.2.2.2 delegated responder, §4.4.1 nonce): https://www.rfc-editor.org/rfc/rfc6960
- RFC 5019 – Lightweight OCSP Profile (pre-produced responses): https://www.rfc-editor.org/rfc/rfc5019
- RFC 8954 – OCSP Nonce Extension: https://www.rfc-editor.org/rfc/rfc8954
- RFC 6066 §8 (status_request), RFC 6961 (multi-stapling), RFC 7633 (TLS Feature / Must-Staple): https://www.rfc-editor.org/rfc/rfc6066, https://www.rfc-editor.org/rfc/rfc6961, https://www.rfc-editor.org/rfc/rfc7633
- RFC 2986 (PKCS#10), RFC 7292 (PKCS#12), RFC 5652 (CMS): https://www.rfc-editor.org/rfc/rfc2986, https://www.rfc-editor.org/rfc/rfc7292, https://www.rfc-editor.org/rfc/rfc5652
- RFC 7030 (EST), RFC 8894 (SCEP), RFC 8555 (ACME), RFC 4210 / RFC 9480 / RFC 9483 (CMP): https://www.rfc-editor.org/rfc/rfc7030, https://www.rfc-editor.org/rfc/rfc8894, https://www.rfc-editor.org/rfc/rfc8555, https://www.rfc-editor.org/rfc/rfc9480, https://www.rfc-editor.org/rfc/rfc9483
- RFC 9171 (Bundle Protocol v7), RFC 9172 (BPSec): https://www.rfc-editor.org/rfc/rfc9171, https://www.rfc-editor.org/rfc/rfc9172
- RFC 6962 / RFC 9162 (Certificate Transparency); RFC 7515 (JWS); RFC 9052 (COSE); RFC 5905 (NTPv4); RFC 8915 (NTS)
- draft-ietf-ntp-roughtime (zatwierdzony jako Experimental RFC 2026-03-17): https://datatracker.ietf.org/doc/draft-ietf-ntp-roughtime/ ; ogłoszenie IESG: https://www.pwg.org/archives/ipp/2026/022045.html
- CA/Browser Forum SC-063 „Make OCSP Optional…”: https://lists.cabforum.org/pipermail/servercert-wg/2023-April/003685.html ; omówienie: https://www.entrust.com/blog/2023/08/short-lived-certificates-finally-approved

**Biblioteki:**
- pyca/cryptography – changelog (wersje: verification 42.0/43.0/45.0/50.0, `verify_directly_issued_by` 40.0, PKCS#12 `encryption_builder` 38.0, latest 50.0.2 z 2026-09-30): https://cryptography.io/en/latest/changelog/
- pyca/cryptography – X.509 verification: https://cryptography.io/en/latest/x509/verification/
- pyca/cryptography issue #10034 (CRL checking w path validation jako przyszła praca): https://github.com/pyca/cryptography/issues/10034
- pyOpenSSL changelog (24.1.0 deprecjacja CRL, 24.3.0 usunięcie, 26.3.0 zapowiedź wycofania X509): https://pyopenssl.org/en/stable/changelog.html
- pyhanko-certvalidator (delta CRL, OCSP, revocation_mode): https://pyhanko.readthedocs.io/en/latest/api-docs/pyhanko_certvalidator.html, https://pypi.org/project/pyhanko-certvalidator/
- crl-checker (deprecated → pki-tools): https://pypi.org/project/crl-checker
- py-libp2p (release notes 0.6.0, intro): https://py-libp2p.readthedocs.io/en/latest/release_notes.html, https://py-libp2p.readthedocs.io/en/latest/introduction.html
- PyScep: https://pypi.org/project/PyScep ; pyD3TN: https://pypi.org/project/pyd3tn ; dtn7-go: https://github.com/dtn7/dtn7-go ; dtn7-rs: https://github.com/gh0st42/dtn7-rs

**Systemy CA:**
- OpenSSL `openssl-ca(1)` 3.5 (crlnumber, „delta CRLs are not currently supported”): https://docs.openssl.org/3.5/man1/openssl-ca/
- CVE-2026-28388 (NULL deref przy delta-CRL bez CRLNumber, tylko z `X509_V_FLAG_USE_DELTAS`): https://access.redhat.com/security/cve/cve-2026-28388
- BoringSSL – usunięcie delta/extended CRL: https://boringssl.googlesource.com/boringssl/+/f86149982323e57050f853c278ce8aa955b681dc%5E%21
- EJBCA – CRL Generation (Delta CRL Period): https://docs.keyfactor.com/ejbca/latest/crl-generation ; CRL Updater Service: https://docs.keyfactor.com/ejbca/9.2/crl-updater-service ; OCSP Response Pre-Production (Enterprise): https://docs.keyfactor.com/ejbca/9.6/ocsp-response-pre-production ; Pre-Signer: https://docs.keyfactor.com/ejbca/9.5/ocsp-response-pre-signer ; CE vs EE: https://www.ejbca.org/community-vs-enterprise
- Dogtag – CRL Configuration: https://www.dogtagpki.org/wiki/CRL_Configuration ; Configuring CRL with PKI Console: https://github-wiki-see.page/m/dogtagpki/pki/wiki/Configuring-CRL-with-PKI-Console
- step-ca – configuration (crl: experimental), revocation (pasywne): https://smallstep.com/docs/step-ca/configuration/, https://smallstep.com/docs/step-ca/revocation/ ; changelog (CRL od v0.23.0): https://git.frostfs.info/TrueCloudLab/certificates/src/tag/v0.23.1/CHANGELOG.md (mirror)
- CFSSL (ocspsign/ocspserve/ocsprefresh): https://pkg.go.dev/github.com/qbit/cfssl/ocsp (mirror), https://github.com/cloudflare/cfssl
- HashiCorp Vault PKI API (delta CRL endpoints, OCSP bez nonce, If-Modified-Since): https://developer.hashicorp.com/vault/api-docs/secret/pki ; release notes 1.12: https://developer.hashicorp.com/vault/docs/v1.12.x/release-notes/1.12.0 ; PR OCSP #16723: https://github.com/hashicorp/vault/pull/16723 ; auto-rebuild: https://support.hashicorp.com/hc/en-us/articles/13868308275219

**Polityki i ekosystem:**
- Microsoft – Crypt32 CRL semantics (NextUpdate, pre-fetch, partitioning): https://learn.microsoft.com/en-us/windows/win32/seccrypto/certificate-revocation-list-semantics
- Microsoft – CRL and Delta CRL Overlap Periods: https://technet.microsoft.com/library/cc731104.aspx
- Let's Encrypt – Ending OCSP: https://letsencrypt.org/2024/12/05/ending-ocsp.html ; LWN: https://lwn.net/Articles/1033809
- Smallstep – OCSP vs CRL: https://smallstep.com/blog/ocsp-vs-crl-explained/

**Do sprawdzenia przed cytowaniem** (pozycje [P], bez źródła z tej sesji): licencje i stan memberlist/Serf
(MPL vs BUSL), Vault (BUSL-1.1), EJBCA CE (LGPL), XCA, toxiproxy, Pumba, libfaketime, time-machine, freezegun;
mechanizmy offline w RFC 9483; zachowanie Windows przy braku ważnej CRL; CRLite/CRLSets.

---

## Załącznik A – wyniki eksperymentów lokalnych

Środowisko: `docker run --rm --entrypoint python projekt_inzynierski-admin-backend …`
(Python 3.11.17, `cryptography` 50.0.2, OpenSSL 3.5.7, uvicorn 0.54.0). Skrypty uruchamiano z katalogu tymczasowego,
bez zmian w repozytorium.

1. **API obecne w `cryptography` 50.0.2:**
   - `x509.CRLNumber`, `DeltaCRLIndicator`, `FreshestCRL`, `IssuingDistributionPoint`,
     `AuthorityKeyIdentifier.from_issuer_public_key`, `SubjectKeyIdentifier.from_public_key`;
   - `x509.verification.{PolicyBuilder, Store, ClientVerifier, ServerVerifier, ExtensionPolicy, Criticality}`;
   - `ocsp.{OCSPRequestBuilder, OCSPResponseBuilder}`;
   - `pkcs12.PBES.{PBESv1SHA1And3KeyTripleDESCBC, PBESv2SHA256AndAES256CBC}`;
   - `pkcs7`: tylko `PKCS7SignatureBuilder`, `PKCS7EnvelopeBuilder`, `pkcs7_decrypt_*`, **bez weryfikacji**;
   - `OCSPResponse`: brak metody weryfikacji podpisu (są `signature` i `tbs_response_bytes`).
2. **Rozmiary DER, podpis EC P-256, losowe 159-bitowe numery seryjne:**
   - pełna CRL z `CRLNumber`: 0 wpisów → 169 B, 1 → 209 B, 10 → 566 B, 100 → 4 075 B, 1000 → 39 173 B;
   - delta-CRL z 1 wpisem → 222 B;
   - odpowiedź OCSP (1 certyfikat) → 262 B; żądanie OCSP → 68 B;
   - PKCS#12 (klucz, certyfikat i CA, AES) → 1 531 B.
3. **Łańcuch:** `ClientVerifier` (domyślna polityka webpki) akceptuje certyfikat z AKI/SKI/KeyUsage/EKU/SAN,
   także z `time()` = teraz + 5 dni. Certyfikat w kształcie z obecnego `ca.py` (tylko `BasicConstraints`) jest
   **odrzucany**: `invalid extension: 2.5.29.35: Certificate is missing required extension`.
   `ExtensionPolicy.permit_all()` dla CA daje błąd „A CA extension policy must require the basicConstraints extension”.
   `verify_directly_issued_by` działa na obu wariantach.
4. **OpenSSL vs delta-CRL zbudowana w `cryptography`** (baza `CRLNumber` = 10; delta `CRLNumber` = 11,
   `DeltaCRLIndicator` = 10, odwołany serial 42):
   - `openssl verify -crl_check` z samą bazą → `OK`;
   - z bazą i deltą oraz `-use_deltas` → `error 23 … certificate revoked`;
   - z bazą i deltą **bez** `-use_deltas` → `OK` (**fail-open**);
   - `-attime` = teraz + 3 dni przy `nextUpdate` = +1 dzień → `error 12 … CRL has expired` (brak okresu łaski).
5. **uvicorn 0.54.0:** opcje `--ssl-keyfile`, `--ssl-certfile`, `--ssl-ca-certs`, `--ssl-cert-reqs` dostępne (mTLS).
