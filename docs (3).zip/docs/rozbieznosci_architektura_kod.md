# Rozbieżności: architektura docelowa ↔ obecna implementacja

> **Stan obecny na dzień audytu: 2026-10-20** (gałąź `maciek`, working tree z niezacommitowaną reorganizacją katalogów).
> Audyt tylko do odczytu – żaden plik kodu nie był zmieniany, nic nie było uruchamiane przez Docker.
>
> Źródła architektury: `architecture.png`, `architecture.excalidraw` (etykiety i strzałki wyciągnięte z JSON),
> `docs/architektura_docelowa.md`. Źródła stanu faktycznego: `admin/`, `edge_client/backend/`, `edge_client/frontend/`, `edge_app/`,
> `docker-compose.yml`, `client.sh`, `scripts/`, `README.md` (tylko do weryfikacji dokumentacji).
>
> Odwołania `plik:linia` dotyczą working tree. Cytaty z diagramu w cudzysłowie to dosłowne etykiety z `.excalidraw`.

---

## 1. Podsumowanie

Zaimplementowana jest **warstwa centralna** (CA w Panelu administratora: wydawanie certyfikatów, odwoływanie, podpisana CRL, pobieranie certyfikatu CA)
oraz **szkielet sieci węzłów brzegowych** (2 kontenery, izolowana sieć P2P, symulacja włączania/wyłączania „internetu”).
Natomiast **rdzeń tematu pracy – dostarczenie danych PKI do węzłów i ich weryfikacja offline – nie istnieje w kodzie usług**:
węzły brzegowe (`edge_app/`) nie mają żadnej logiki PKI (brak magazynu certyfikatu CA/CRL, brak weryfikacji łańcucha i CRL,
brak protokołu gossip, brak `CRLNumber`), a kanał WAN „Łączność → Edge client” z diagramu nie istnieje – sieć `internet_net`
węzłów nie jest połączona z siecią `pki-network`, w której działa backend klienta (rola „Łączności”).
Komponent „Edge app” z diagramu nie ma żadnego odpowiednika. Weryfikacja offline istnieje wyłącznie jako skrypty demonstracyjne
uruchamiane na hoście (`scripts/demo_offline_auth.*`), które przy okazji **podpisują certyfikaty kluczem Root CA poza `admin/backend/`**.
Z granic zaufania zachowane jest najważniejsze: klucz CA nie trafia do repozytorium ani do kontenerów `edge_client/` i `edge_app/`, a te komponenty niczego nie podpisują;
odstępstwa to wbudowanie klucza w obraz Dockera admina, pełne prawa zapisu do bazy dla „Łączności” (diagram: „SQL (READ)”)
oraz CRL pobierana przez HTTP z admina zamiast z bazy. Ogólny stopień zgodności oceniam na **ok. 30–35%**: zgodna jest
topologia centrum, niezgodna lub nieobecna – cała część „ograniczonej łączności”.

---

## 2. Tabela główna

Legenda wag: **krytyczna** – łamie wymaganie działania offline albo zasadę bezpieczeństwa; **istotna** – rozjazd z architekturą wpływający na
funkcję lub model zaufania; **drobna** – kosmetyka / dokumentacja.

### 2.1 Komponenty

| # | Obszar | Element docelowy | Stan | Dowód (plik:linia) | Opis różnicy | Waga |
|---|---|---|---|---|---|---|
| 1 | Komponenty | Całość w jednym „docker compose” (etykieta w lewym górnym rogu diagramu) | INACZEJ | `docker-compose.yml:3-86`, `edge_app/docker-compose.yml:3-58`, `client.sh:4` | Dwa niezależne pliki compose (centrum i węzły) uruchamiane osobno; brak wspólnej sieci między nimi. | istotna |
| 2 | Komponenty | Panel administratora – „React frontend” (osobny kontener) | ZGODNE | `docker-compose.yml:39-48`, `admin/frontend/Dockerfile:1-7`, `admin/frontend/src/App.jsx:21` | Osobny kontener `admin-frontend` (Vite dev server, port 3000), REST do `localhost:5000/api`. | – |
| 3 | Komponenty | Panel administratora – „FastAPI backend” | ZGODNE | `docker-compose.yml:25-37`, `admin/backend/main.py:29-46` | FastAPI na porcie 5000, routery users/certificates/health. | – |
| 4 | Komponenty | Panel administratora – „cryptography lib (OpenSSL)”, strzałka „CALL” | ZGODNE | `admin/backend/requirements.txt:5`, `admin/backend/pki/ca.py:4-7` | Biblioteka `cryptography` (backend OpenSSL) wywoływana w `pki/ca.py`. | – |
| 5 | Komponenty | „PostgreSQL” (osobny kontener) | ZGODNE | `docker-compose.yml:6-21`, `admin/backend/init.sql:1-26` | Postgres 15, tabele `users`, `certificates`. Brak tabeli na podpisane CRL (por. #24). | – |
| 6 | Komponenty | „Łączność” – „FastAPI backend”, bez frontendu | CZĘŚCIOWO | `docker-compose.yml:54-68`, `edge_client/backend/main.py:27-44` | Rolę pełni `edge-client-backend` (port 5001). Mapowanie wynika z docs (`architektura_docelowa.md:40`), w kodzie nazwa „Łączność” nie występuje. Dodatkowo istnieje `edge-client-frontend` – nieobecny na diagramie (pkt 3). | drobna |
| 7 | Komponenty | „Edge client 1/2” – „React frontend” w osobnym kontenerze | INACZEJ | `edge_app/client_node.py:24-40`, `edge_app/docker-compose.yml:18-19` | Frontend (`edge_app/static/app.jsx`, React z CDN/vendor) serwowany przez ten sam proces FastAPI (`StaticFiles`), nie osobny kontener. | drobna |
| 8 | Komponenty | „Edge client 1/2” – „FastAPI backend” | CZĘŚCIOWO | `edge_app/client_node.py:18-45`, `edge_app/docker-compose.yml:4-42` | Dwa kontenery FastAPI istnieją, ale są wyłącznie węzłami komunikacyjnymi (diagnostyka sieci, czat, transfer plików) – zero funkcji PKI (zob. #18–#27). | krytyczna |
| 9 | Komponenty | „Edge app 1/2” (React frontend + FastAPI backend, osobne kontenery) | BRAK | brak w `docker-compose.yml`, `edge_app/docker-compose.yml`; `grep` po repo bez wyników | Brak jakiegokolwiek komponentu relying party / aplikacji końcowej. | istotna |
| 10 | Komponenty | Root CA (docs: „Root offline + Issuing CA” – przynajmniej opis) | CZĘŚCIOWO | `admin/backend/pki/ca.py:27-53`, `:112` | Jeden poziom: samopodpisany Root CA (RSA 4096, 10 lat) podpisuje bezpośrednio certyfikaty końcowe. Docs dopuszcza to jako uproszczenie (`architektura_docelowa.md:122`). | drobna |

### 2.2 Kanały komunikacji

| # | Obszar | Element docelowy | Stan | Dowód (plik:linia) | Opis różnicy | Waga |
|---|---|---|---|---|---|---|
| 11 | Kanały | Panel: React → FastAPI, „REST API (HTTP)” | ZGODNE | `admin/frontend/src/App.jsx:21`, `:55-164` | axios do `http://localhost:5000/api`. (Na `.excalidraw` ta strzałka ma tylko `startBinding`, koniec niepodpięty – kosmetyka diagramu.) | – |
| 12 | Kanały | Panel FastAPI → PostgreSQL, „SQL (READ/WRITE)” | ZGODNE | `admin/backend/database.py:9-32`, `admin/backend/routers/certificates.py:90-112`, `:132-137` | asyncpg, INSERT/UPDATE certyfikatów, CRUD użytkowników. | – |
| 13 | Kanały | Łączność → PostgreSQL, „SQL (READ)” | CZĘŚCIOWO | `edge_client/backend/routers/*.py` (tylko `SELECT`), `docker-compose.yml:62` | Kod wykonuje tylko SELECT, ale łączy się tym samym kontem `pki_admin` z pełnymi prawami – „tylko odczyt” nie jest wymuszony na poziomie bazy. | istotna |
| 14 | Kanały | Łączność → Admin (HTTP) – **nieobecne na diagramie** | INACZEJ | `edge_client/backend/routers/certificates.py:13`, `:72-113`, `docker-compose.yml:63` | `edge-client-backend` proxuje `/ca` i `/crl` do `admin-backend:5000`. Diagram zakłada, że Łączność czyta wyłącznie z bazy (docs `:37-40` – znana niespójność). Przy niedostępnym adminie Łączność nie poda ani certu CA, ani CRL (`:88-91`, `:109-113`). | istotna |
| 15 | Kanały | Łączność → Edge client 1/2, „łączność zewnętrzna WAN” | BRAK | `edge_app/docker-compose.yml:69-71`, `docker-compose.yml:81-83`, `edge_app/client.sh:72` | `internet_net` to osobna sieć bridge bez kontenerów centrum; `pki-network` nie jest do niej podłączona. Węzły nie mają w kodzie ani adresu Łączności, ani klienta HTTP do niej (`edge_app/config.py:6-22`). „Online” = dostęp do publicznego internetu (1.1.1.1, timeapi.io), nie do PKI. | krytyczna |
| 16 | Kanały | Kierunek inicjacji WAN (diagram: strzałki od Łączności = push; docs `:47`: „kod robi pull”) | NIEJASNE | – | Brak jakiegokolwiek kanału, więc kierunek nierozstrzygalny. Uwaga: zdanie w docs „kod robi pull” dotyczy przeglądarki/portalu klienta, nie węzłów. | drobna |
| 17 | Kanały | Edge client 1 ↔ Edge client 2, „izolowana sieć wewnętrzna” | ZGODNE | `edge_app/docker-compose.yml:60-67` (`internal: true`, 192.168.50.0/24), `edge_app/routers/p2p.py:16-65` | Sieć izolowana istnieje, test łączności P2P działa. | – |
| 18 | Kanały | Edge client ↔ Edge client, „crl ???” (dane PKI przez P2P) | CZĘŚCIOWO | `edge_app/routers/p2p.py:123-169`, `edge_app/client.sh:203-220` | Tylko ręczny, generyczny transfer pliku (`send-file`/`receive-file`) inicjowany przez użytkownika. Brak semantyki CRL, brak automatyzmu. | krytyczna |
| 19 | Kanały | Edge client → Edge app, „cert” | BRAK | – | Brak Edge app (#9) i brak endpointu udostępniającego certyfikat. | istotna |
| 20 | Kanały | Edge app 1 ↔ Edge app 2, „izolowana sieć wewnętrzna (opcjonalna)” | BRAK | – | Brak Edge app. Oznaczone na diagramie jako opcjonalne. | drobna |
| 21 | Kanały | Edge client/app: React → FastAPI „REST API (HTTP)” | CZĘŚCIOWO | `edge_app/static/app.jsx:177-376`, `edge_app/nginx_gateway.conf:6-24` | Dla Edge client – REST do tego samego originu przez bramkę nginx (8001/8002). Dla Edge app – brak. | drobna |

### 2.3 Przepływy danych PKI

| # | Obszar | Element docelowy | Stan | Dowód (plik:linia) | Opis różnicy | Waga |
|---|---|---|---|---|---|---|
| 22 | Przepływy | Wydanie certyfikatu w CA | ZGODNE | `admin/backend/routers/certificates.py:45-118`, `admin/backend/pki/ca.py:67-136` | X.509 v3, RSA 2048, 365 dni, `BasicConstraints(ca=False)`. Zapis do bazy. Brak rozszerzeń SKI/AKI/KeyUsage (istotne dla docs `:74`: „AKI == SKI CA”). | drobna |
| 23 | Przepływy | Dystrybucja klucza prywatnego: CSR (PKCS#10) na węźle lub zaszyfrowany PKCS#12 (docs `:55`, `:92`) | INACZEJ | `admin/backend/pki/ca.py:85-89`, `:119-123`, `admin/backend/routers/certificates.py:116`, `admin/frontend/src/App.jsx:641` | Klucz generowany przez CA, niezaszyfrowany PKCS#8 PEM zwracany w JSON przez HTTP i pobierany z przeglądarki admina. Brak endpointu CSR. Docs poprawnie to opisuje jako stan obecny. | istotna |
| 24 | Przepływy | CRL podpisana przez CA i zapisana (DER) do bazy; Łączność czyta ją z bazy (docs `:38-39`) | INACZEJ | `admin/backend/pki/ca.py:139-202`, `admin/backend/routers/certificates.py:148-155`, `:182-208`, `admin/backend/init.sql` (brak tabeli CRL) | CRL zapisywana do plików `pki_data/crl.pem`/`crl.der` w kontenerze admina; **każde `GET /crl` generuje i podpisuje nową CRL** (nowe `thisUpdate`). Brak okresowego generowania (tylko przy odwołaniu i przy pobraniu). | istotna |
| 25 | Przepływy | Dystrybucja certyfikatu CA (trust anchor) do węzłów | CZĘŚCIOWO | `admin/backend/routers/certificates.py:166-179`, `edge_client/backend/routers/certificates.py:72-91`, `edge_client/frontend/src/App.jsx:79` | Do pobrania przez przeglądarkę z portalu klienta. Do węzłów `edge_app/` nie trafia żadną automatyczną drogą. | krytyczna |
| 26 | Przepływy | Dystrybucja certyfikatu użytkownika/węzła | CZĘŚCIOWO | `edge_client/backend/routers/certificates.py:41-69`, `edge_client/frontend/src/App.jsx:68`, `:258` | Pobranie PEM ręcznie przez portal; brak mechanizmu dostarczenia do węzła. | istotna |
| 27 | Przepływy | Dystrybucja CRL przy stałej łączności („Łączność serwuje podpisaną CRL z bazy”) | INACZEJ | `edge_client/backend/routers/certificates.py:94-113` | Proxy HTTP do admina (zob. #14, #24). | istotna |
| 28 | Przepływy | Store-and-forward (dane docierają pośrednio, gdy łącze do centrum niedostępne) | BRAK | `edge_app/routers/p2p.py:68-92`, `:123-146`, `edge_app/state.py:5` | Wysyłka jest synchroniczna: gdy sąsiad niedostępny → HTTP 503, brak kolejki i ponowień. Odebrane pliki nie są przekazywane dalej. Skrzynka wiadomości trzymana w pamięci procesu; katalog `received_files` bez wolumenu (`edge_app/docker-compose.yml:18-19`). | krytyczna |
| 29 | Przepływy | Gossip CRL: `GET /pki/summary`, `GET /pki/crl`, porównanie `crl_number` (docs `:66-80`) | BRAK | `edge_app/routers/p2p.py:13` (jedyne prefiksy: `/api/p2p`, `/api/...`) | Brak endpointów `/pki/*`, brak cyklicznej synchronizacji, brak powiadamiania sąsiadów. | krytyczna |

### 2.4 Weryfikacja i nieaktualność danych

| # | Obszar | Element docelowy | Stan | Dowód (plik:linia) | Opis różnicy | Waga |
|---|---|---|---|---|---|---|
| 30 | Weryfikacja | „Weryfikator + magazyn PKI” na węźle: łańcuch do Root CA, ważność, status w CRL (docs `:58`) | BRAK (w usługach) / CZĘŚCIOWO (skrypty) | `edge_app/requirements.txt:5` (`cryptography` zainstalowane, nieużywane – `grep` w `edge_app/*.py` bez trafień), `scripts/demo_offline_auth.sh:61-79`, `scripts/demo_offline_auth.py:37-65`, `:99-115` | Weryfikacja offline istnieje tylko jako skrypty hosta (`openssl verify -crl_check` / `cryptography`). Węzeł nie przechowuje certu CA ani CRL i niczego nie weryfikuje. | krytyczna |
| 31 | Weryfikacja | Weryfikacja podpisu CA na danych od pośrednika przed użyciem | BRAK | `edge_app/routers/p2p.py:149-169` | Odebrany plik zapisywany bez żadnej weryfikacji. **Regres**: wersja w `HEAD` (`clients/routers/p2p.py`) sprawdzała chociaż SHA-256; teraz parametr `expected_sha256` (`p2p.py:154`) jest ignorowany, a import `hashlib` (`p2p.py:1`) martwy. | krytyczna |
| 32 | Nieaktualność | `CRLNumber` (RFC 5280 §5.2.3) + ochrona przed rollbackiem | BRAK | `admin/backend/pki/ca.py:156-161` | Builder CRL bez rozszerzenia `CRLNumber`; potwierdza to `openssl crl -text` dla `admin/backend/pki_data/crl.pem` (brak pola „CRL Number”). Brak też `AuthorityKeyIdentifier`. | krytyczna |
| 33 | Nieaktualność | `thisUpdate`/`nextUpdate` + polityka świeżości (okres łaski, hard/soft-fail) | CZĘŚCIOWO | `admin/backend/pki/ca.py:159-160` | Pola ustawiane (`nextUpdate` = now + 30 dni), ale nigdzie nie ma polityki ich oceny ani raportu „PKI nieaktualne od X h”. Śledzony w git `scripts/crl.pem` ma `nextUpdate` = 13.10.2026 (7 dni; już przeterminowany) – artefakt starszej wersji. | istotna |
| 34 | Nieaktualność | Tolerancja rozjazdu zegara węzłów (`thisUpdate <= now + skew_tolerance`) | BRAK | `edge_app/routers/network.py:41-108`, `edge_app/config.py:14-15` | Jest tylko diagnostyczny odczyt zewnętrznego zegara (`/api/clock`) – bez porównania z lokalnym czasem i bez użycia w jakiejkolwiek decyzji. | istotna |
| 35 | Nieaktualność | Ten sam mechanizm dla certyfikatów i rolloveru certu CA (docs `:84`) | BRAK | – | Brak wersjonowania certyfikatów (`certs_version`) i obsługi rolloveru. | istotna |
| 36 | Bezpieczeństwo P2P | Uwierzytelnianie P2P (podpis wiadomości certyfikatem węzła lub mTLS – docs `:93`) | BRAK | `edge_app/routers/p2p.py:95-111`, `:149-160` | `sender_id`/`sender_name` podawane przez nadawcę bez weryfikacji; zwykłe HTTP. Docs dopuszcza to jako opisane ograniczenie (`:121`), o ile integralność da podpis CA (którego brak – #31). | istotna |

### 2.5 Granice zaufania

| # | Obszar | Element docelowy | Stan | Dowód (plik:linia) | Opis różnicy | Waga |
|---|---|---|---|---|---|---|
| 37 | Zaufanie | Klucz CA tylko w Panelu administratora | CZĘŚCIOWO | `admin/backend/pki/ca.py:10-11`, `:55-61`, `scripts/demo_offline_auth.sh:42`, `scripts/demo_offline_auth.py:168`, `:194` | W usługach – tylko admin. Ale skrypty demonstracyjne na hoście czytają `ca_private_key.pem` i podpisują nim certyfikaty z pominięciem CA (szczegóły w pkt 5). Klucz niezaszyfrowany (`NoEncryption`). | krytyczna |
| 38 | Zaufanie | Podpisuje wyłącznie CA (certyfikaty, CRL) | ZGODNE (usługi) | `admin/backend/pki/ca.py:52`, `:112`, `:194` | Jedyne wywołania `.sign(` w usługach są w `admin/backend/pki/ca.py`. | – |
| 39 | Zaufanie | Łączność i węzły tylko weryfikują | INACZEJ | `edge_client/backend/`, `edge_app/` | Nie podpisują (zgodnie), ale też **nic nie weryfikują** – w żadnym z nich nie ma kodu kryptograficznego. | krytyczna |
| 40 | Zaufanie | Komponent wystawiony na WAN nie może niczego zmienić (docs `:30-31`) | CZĘŚCIOWO | `docker-compose.yml:62`, `docker-compose.yml:15-16` | Kod `edge-client-backend` tylko czyta, ale ma poświadczenia właściciela bazy; dodatkowo Postgres wystawiony na hosta (`5433:5432`). | istotna |

---

## 3. Elementy obecne w kodzie, a nieobecne na diagramie

1. **Kontener `edge-client-frontend` (portal klienta, React/Vite, port 3001)** – `docker-compose.yml:69-79`, `edge_client/frontend/src/App.jsx:18`. Na diagramie „Łączność” ma tylko „FastAPI backend”.
2. **Kanał HTTP Łączność → Panel administratora** (`ADMIN_BACKEND_URL`) – `docker-compose.yml:63`, `edge_client/backend/routers/certificates.py:13`, `:78`, `:100`.
3. **Bramka `edge_app_gateway` (nginx, porty 8001/8002)** łącząca hosta z siecią izolowaną – `edge_app/docker-compose.yml:44-58`, `edge_app/nginx_gateway.conf:1-25`, oraz sieć `gateway_net` (`edge_app/docker-compose.yml:73-75`).
4. **Sieć `internet_net` i mechanizm „internet on/off”** (`docker network connect/disconnect`) – `edge_app/docker-compose.yml:69-71`, `edge_app/client.sh:44-84`. Na diagramie jest „łączność zewnętrzna WAN”, ale do Łączności, nie do publicznego internetu.
5. **Zależność węzłów od zewnętrznych usług internetowych**: timeapi.io, worldtimeapi.org (`edge_app/config.py:14-15`), 1.1.1.1, dns.google, api.ipify.org (`edge_app/routers/network.py:117-128`, `:174`, `:193`).
6. **Endpointy węzła niezwiązane z PKI**: `/api/status`, `/api/clock`, `/api/internet/check`, `/api/internet/test` (`edge_app/routers/network.py:15-227`), `/api/p2p/test|send-message|receive-message|inbox|send-file|receive-file|files|files/{name}` (`edge_app/routers/p2p.py:16-221`).
7. **Endpointy portalu klienta**: `GET /api/users`, `/api/users/{id}`, `/api/certificates`, `/api/certificates/user/{id}`, `/api/certificates/ca[/download]`, `/api/certificates/crl[/download]`, `/api/health` – `edge_client/backend/routers/*.py`.
8. **Endpointy admina** (zarządzanie użytkownikami: `POST/DELETE /api/users`) – `admin/backend/routers/users.py:40-87`; diagram nie opisuje API, więc to tylko uzupełnienie.
9. **Port Postgresa wystawiony na hosta** (`5433:5432`) – `docker-compose.yml:15-16`.
10. **Skrypty demonstracyjne weryfikacji offline** na hoście – `scripts/demo_offline_auth.sh`, `scripts/demo_offline_auth.py` – oraz śledzone w git artefakty `scripts/ca_certificate.pem`, `scripts/Bob_cert.pem`, `scripts/crl.pem`.
11. **Dane seed** w `init.sql:35-37` – certyfikaty `SN-...` bez treści PEM (pseudo-numery seryjne; `ca.py:170-174` ma do nich specjalny parser).
12. **Zbędne pliki w `edge_client/frontend/`**: `main.jsx`, `index.css` w katalogu głównym obok `src/main.jsx`, `src/index.css` – drobny bałagan po reorganizacji.

**Ze starych katalogów** (usuniętych w working tree): żaden element diagramu nie istniał wyłącznie tam. Jedyna utracona funkcja to weryfikacja SHA-256 przy transferze P2P w `HEAD:clients/routers/p2p.py` (zob. #31). Natomiast `scripts/demo_offline_auth.py:167-169` nadal wskazuje stare ścieżki `backend/pki_data/...` (nieistniejące po reorganizacji) – tryb self-test tego skryptu nie zadziała.

---

## 4. Niespójności diagram ↔ `docs/architektura_docelowa.md`

1. **Źródło CRL dla Łączności** – diagram: Łączność ma tylko „SQL (READ)” do bazy; docs (`:37-39`) wymaga, by CA zapisywała podpisaną CRL do bazy. Diagram nie pokazuje CRL w bazie ani zapisu CRL przez Panel (strzałka „SQL (READ/WRITE)” jest ogólna). Docs to opisuje jako niespójność do poprawienia – diagram nie został poprawiony.
2. **„crl ???”** – diagram nadal ma znak zapytania; docs (`:41-42`, `:84`) definiuje, że P2P niesie podpisaną CRL **oraz** certyfikaty i cert CA (rollover). Diagram tego nie odzwierciedla.
3. **Weryfikator + magazyn PKI** – docs (`:21`, `:58`) przypisuje Edge client lokalny magazyn i weryfikację offline; na diagramie Edge client to tylko „React frontend” + „FastAPI backend” bez takiego elementu (i bez biblioteki kryptograficznej, którą ma Panel).
4. **Rola Edge app vs Edge client oraz zawartość strzałki „cert”** – diagram jej nie rozstrzyga, docs oznacza jako „do doprecyzowania” (`:45-46`). Pozostaje otwarte.
5. **Kierunek WAN** – na `.excalidraw` strzałki WAN wychodzą z linii nad/pod Łącznością i nie mają `startBinding`/`endBinding` (nie są przypięte do żadnego elementu); grot przy Edge client sugeruje push. Docs (`:47`) twierdzi, że „kod robi pull” – w rzeczywistości w kodzie węzłów kanału WAN do Łączności nie ma wcale (#15), więc to stwierdzenie docs jest nieprecyzyjne.
6. **Model CA** – diagram: jedno CA w Panelu; docs (`:53`, `:90`, `:122`) – „Root offline + Issuing CA” jako model opisany w pracy. Spójne tylko przy założeniu, że to wyłącznie opis teoretyczny.
7. **Endpointy protokołu** (`/pki/summary`, `/pki/crl`), okresowe generowanie CRL, polityka świeżości, mTLS – są tylko w docs, na diagramie brak jakiejkolwiek adnotacji.
8. **„Całość uruchamiana przez Docker Compose”** (docs `:14`, diagram „docker compose”) – oba dokumenty zakładają jeden compose; nie jest to niespójność między nimi, ale oba są niezgodne z kodem (#1).
9. **Drobne w `.excalidraw`**: strzałka „REST API (HTTP)” w Panelu nie ma `endBinding`; etykiety „kontener” są przy każdym pod-prostokącie (sugeruje osobny kontener dla każdego frontendu i backendu, czego docs nie precyzuje, a kod realizuje różnie – #7).
10. **Stany obecne w docs** – sprawdzone i nadal prawdziwe: `nextUpdate` = 30 dni (`ca.py:160`), brak `CRLNumber`, klucz w JSON (`certificates.py:116`), proxy CRL do admina. Nieaktualne/nieprecyzyjne: „Dystrybucja CRL (przerywana łączność) – Brak (generyczny transfer plików)” – trafne, ale transfer ten utracił nawet kontrolę SHA-256 (#31).

---

## 5. Sprawdzenie reguł bezpieczeństwa z CLAUDE.md

### 5.1 „Klucz prywatny Root CA nigdy nie trafia do repozytorium”
- **ZGODNE.** `admin/backend/pki_data/ca_private_key.pem` jest ignorowany (`admin/backend/.gitignore:1` `pki_data/`, `.gitignore:1-3` `pki_data/`, `*.key`, `*.pem`). `git ls-files` nie zawiera żadnego klucza; `git log --all -- '*.pem' '*.key' '*pki_data*'` pokazuje tylko `scripts/Bob_cert.pem`, `scripts/ca_certificate.pem`, `scripts/crl.pem` (commit `e85c405`) – to certyfikaty i CRL (nagłówki `BEGIN CERTIFICATE` / `BEGIN X509 CRL`), bez materiału prywatnego.
- Uwaga: `scripts/ca_certificate.pem` jest identyczny z bieżącym `admin/backend/pki_data/ca_certificate.pem` (`cmp`) – publiczny, więc dopuszczalny, ale jest ręcznie skopiowaną migawką.

### 5.2 „…ani do komponentów poza `admin/backend/`”
- **Wolumeny / montowania**: **ZGODNE.** Żaden serwis nie montuje `pki_data` – `docker-compose.yml:17-19` (tylko `pgdata` i `init.sql`), `edge_app/docker-compose.yml:18-19`, `:38-39`, `:51-52` (tylko `static/` i `nginx_gateway.conf`).
- **Obrazy Dockera**: **CZĘŚCIOWO / ryzyko.** `admin/backend/Dockerfile:11` wykonuje `COPY . .`, a `admin/backend/.dockerignore:1-13` **nie wyklucza `pki_data/`** – lokalny klucz Root CA zostaje wbudowany w warstwę obrazu `admin-backend`. Formalnie to nadal komponent `admin/backend`, ale klucz staje się częścią artefaktu (wyciek przy publikacji obrazu do rejestru, utrwalony w historii warstw). Dodatkowo brak wolumenu powoduje, że CRL i ewentualnie nowy klucz generowane w kontenerze giną przy jego odtworzeniu, a stan na hoście i w kontenerze się rozjeżdża. Waga: **krytyczna** (zasada bezpieczeństwa klucza CA).
- `edge_client/backend/` nie ma `.dockerignore`, ale nie zawiera `pki_data` – brak ryzyka. `edge_app/.dockerignore` wyklucza `received_files/`; katalog nie zawiera klucza.
- **Skrypty hosta**: **NARUSZENIE.** `scripts/demo_offline_auth.sh:11`, `:42` (`-CAkey "$PKI_DATA/ca_private_key.pem"`) oraz `scripts/demo_offline_auth.py:168`, `:178`, `:194` (`.sign(ca_key, ...)`) używają klucza CA spoza `admin/backend/` i podpisują nim certyfikat testowego węzła z pominięciem CA (brak wpisu w bazie → certyfikatu nie da się odwołać przez Panel). Klucz nie jest kopiowany, ale jest używany przez komponent spoza CA. Waga: **krytyczna** wg definicji audytu (łamie zasadę), choć praktyczny zasięg ogranicza się do demo.

### 5.3 „`edge_client/backend` i `edge_app/` nie mogą podpisywać niczego kluczem CA – tylko weryfikują”
- **Podpisywanie: ZGODNE.** `grep` po `sign(`, `private_key`, `ca_private`, `pki_data` w `edge_client/backend/` i `edge_app/` – brak trafień (poza tekstowymi rozszerzeniami plików `.key` w `edge_app/routers/p2p.py:200`, `edge_app/static/app.jsx:356`). `edge_client/backend/requirements.txt:1-5` nie zawiera `cryptography`. `edge_app/requirements.txt:5` zawiera `cryptography`, ale biblioteka nie jest importowana.
- **„Tylko weryfikują”: NIESPEŁNIONE** – żaden z tych komponentów niczego nie weryfikuje (#30, #31, #39).
- **Dodatkowo**: `edge_client/backend` ma pełne poświadczenia bazy (`docker-compose.yml:62`) – nie może podpisać, ale może zmienić status certyfikatu w tabeli, z której CA buduje CRL (`admin/backend/routers/certificates.py:150-153`). Pośrednio pozwala to wpłynąć na treść podpisywanej przez CA CRL. Waga: **istotna**.

### 5.4 Inne obserwacje bezpieczeństwa
- Klucz Root CA niezaszyfrowany na dysku (`ca.py:59`).
- Klucz prywatny użytkownika przesyłany jawnie w JSON (`certificates.py:116`) – CORS `allow_origins=["*"]` z `allow_credentials=True` (`admin/backend/main.py:36-42`) i brak uwierzytelniania API admina.
- Hasło bazy na sztywno w `docker-compose.yml:13`, `:34`, `:62` i jako domyślne w `database.py:11` obu backendów.
- Odebrane przez P2P pliki są zapisywane pod nazwą od nadawcy (`p2p.py:157-160`; `Path(...).name` chroni przed path traversal, ale nie przed nadpisaniem).

---

## 6. Rekomendowana kolejność domykania luk (bez implementacji)

1. **Usunąć wycieki klucza CA** (szybkie, krytyczne): dodać `pki_data/` do `admin/backend/.dockerignore` i trzymać klucz na wolumenie (#5.2); przepisać `scripts/demo_offline_auth.*` tak, by certyfikat testowy wydawało CA przez API, a skrypt tylko weryfikował; poprawić stare ścieżki w `.py`.
2. **Uzupełnić CRL o `CRLNumber` (+ AKI/SKI w certyfikatach)** i przestać re-podpisywać CRL przy każdym `GET` – podstawa całego protokołu i ochrony przed rollbackiem (#32, #24, #22).
3. **CRL i cert CA w bazie; Łączność czyta tylko z bazy** na osobnym koncie z prawem `SELECT` – realizacja strzałki „SQL (READ)” i usunięcie kanału HTTP do admina (#13, #14, #24, #27, #40); okresowe generowanie CRL po stronie CA.
4. **Kanał WAN Łączność ↔ Edge client**: wspólna sieć (lub jeden compose) + klient na węźle pobierający cert CA, CRL i certyfikaty; `internet on/off` ma odcinać właśnie ten kanał (#1, #15, #25, #26). Rozstrzygnąć push vs pull (#16).
5. **Weryfikator + magazyn PKI na węźle**: trwały wolumen, lokalny trust anchor, weryfikacja łańcucha/ważności/CRL offline, endpoint do weryfikacji (#30, #39) – to rdzeń wymagania „działanie offline”.
6. **Gossip CRL P2P** wg docs `:66-80` (`/pki/summary`, `/pki/crl`, weryfikacja podpisu, monotoniczny `CRLNumber`, zapis atomowy, propagacja) zamiast ręcznego `send-file`; kolejka store-and-forward (#18, #28, #29, #31).
7. **Polityka świeżości i rozjazd zegara**: ocena `nextUpdate`, okres łaski, hard/soft-fail, tolerancja skew, raport „PKI nieaktualne od X h” (#33, #34).
8. **Edge app** jako minimalny relying party konsumujący „cert” z Edge client (lub świadome połączenie z Edge client – docs `:119`) (#9, #19, #20).
9. **Dystrybucja klucza prywatnego przez CSR** (lub zaszyfrowany PKCS#12) (#23); rollover certu CA i certyfikatów przez ten sam mechanizm (#35).
10. **Uwierzytelnianie P2P** (podpis wiadomości / mTLS) lub jawne opisanie jako ograniczenia (#36).
11. **Porządki dokumentacyjne**: zaktualizować diagram (CRL w bazie, opis „crl ???”, weryfikator na węźle, portal klienta, gateway, dwa compose lub jeden), poprawić zdanie o „pull” w docs, README (`README.md:111` – „Publiczne API weryfikacji” – backend klienta nie ma żadnego endpointu weryfikacji), usunąć zdublowane pliki w `edge_client/frontend/` i nieaktualny `scripts/crl.pem`.
