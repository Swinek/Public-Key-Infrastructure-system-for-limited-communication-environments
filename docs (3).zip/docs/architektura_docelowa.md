# Architektura docelowa – podsumowanie i ocena

> **Uwaga:** ten dokument opisuje **architekturę docelową** (cel projektu), a nie stan obecnej implementacji.
> Wiele opisanych elementów (protokół wymiany CRL między węzłami, weryfikator offline na węźle,
> `CRLNumber`, polityka świeżości danych, bezpieczna dystrybucja klucza prywatnego) **nie jest jeszcze
> zrealizowanych**. Rozbieżności z aktualnym kodem są zaznaczone jako „stan obecny”.

Źródło: ocena diagramu `architecture.png` / `architecture.excalidraw` (rozmowa z Claude Code, 2026-10-20).

> **Korekta 2026-10-21:** mapowanie komponentów w tabeli poniżej było błędne. Według autora projektu
> **Łączność** = skrypt `client.sh internet on/off` (nie `edge_client/backend`), **Edge app** = `edge_app/`,
> **Edge client** = `edge_client/` (potwierdzone 2026-10-24). Zamiast jednego compose przyjęto **dwa pliki compose**
> (centrum i węzły) ze wspólną siecią zewnętrzną `internet_net`. Szczegóły w `AGENTS.md`
> („Podział na centrum i węzły”). Zdania „Delta-CRL – opcjonalnie” (§4) i „Pełna CRL zamiast delta-CRL” (§8)
> zastępuje decyzja o adaptacyjnych deltach (`AGENTS.md`).

---

## 1. Komponenty (wg diagramu)

Całość uruchamiana przez Docker Compose, każdy komponent w osobnym kontenerze.

| Komponent | Rola | Połączenia |
|---|---|---|
| **Panel administratora** (React + FastAPI + `cryptography`/OpenSSL) | Root CA: wydawanie, odwoływanie, generowanie i podpis CRL. Jedyne miejsce z kluczem CA. | → PostgreSQL: SQL READ/WRITE |
| **PostgreSQL** | Wspólna baza: użytkownicy, certyfikaty, (docelowo) podpisane CRL | ← Panel (RW), ← Łączność (READ) |
| **Łączność** (FastAPI) | Warstwa publikacji/repozytorium wystawiona na WAN; nic nie podpisuje | → PostgreSQL: SQL READ; → Edge client 1/2 przez WAN |
| **Edge client 1, 2** (React + FastAPI) | Węzeł brzegowy PKI: lokalny magazyn (cert CA, CRL, certyfikaty), weryfikacja offline, wymiana P2P | ↔ drugi Edge client (izolowana sieć wewnętrzna, „crl ???”); → Edge app („cert”) |
| **Edge app 1, 2** (React + FastAPI) | Aplikacja końcowa korzystająca z certyfikatu (relying party / end entity) | ← Edge client („cert”); ↔ druga Edge app (opcjonalna sieć wewnętrzna) |

## 2. Ocena spójności diagramu

**Werdykt:** diagram stanowi spójną i logiczną podstawę do realizacji tematu, pod warunkiem dwóch poprawek.

### Co jest poprawne
- Podział **centrum (CA) → warstwa dystrybucji → węzły brzegowe** odpowiada problemowi.
- **Łączność ma tylko odczyt bazy** – komponent wystawiony na WAN nie może niczego podpisać ani zmienić
  (analogia: rozdział CA od repozytorium/publishera w EJBCA, podsystemów w Dogtag).
- Rozdzielenie **łącza WAN** od **sieci P2P między węzłami** – dane mogą dotrzeć z centrum albo od sąsiada.
- **Klucz CA tylko w jednym miejscu** (Panel administratora), węzły go nie widzą.
- Osobne kontenery umożliwiają symulację odcinania łącza i testy.

### Niespójności logiczne do poprawienia
1. **Skąd Łączność bierze podpisaną CRL?** Ma tylko odczyt bazy, a CRL musi podpisać CA.
   Docelowo: **CA generuje i podpisuje CRL (przy odwołaniu i okresowo) i zapisuje gotowy DER do bazy**,
   Łączność tylko ją czyta.
   *Stan obecny:* `edge_client/backend` pobiera CRL przez HTTP z backendu admina – połączenie nieobecne na diagramie.
2. **„crl ???”** to nie szczegół, lecz rdzeń tematu – na diagramie trzeba podpisać, co płynie P2P
   (podpisana CRL, ewentualnie certyfikaty / cert CA).

### Do doprecyzowania na diagramie
- Rola **Edge app vs Edge client** – kto wykonuje weryfikację offline.
- Czy strzałka **„cert”** niesie też klucz prywatny.
- **Kierunek inicjacji WAN** – push z centrum czy pull przez węzeł (strzałki sugerują push, kod robi pull).

## 3. Mapowanie na cel pracy (stan docelowy)

| Element celu | Realizacja docelowa | Stan obecny |
|---|---|---|
| Tworzenie i utrzymanie CA | Root CA w Panelu administratora; w pracy opisany model Root offline + Issuing CA | Root CA podpisuje bezpośrednio, klucz w `pki_data/` |
| Wydawanie i dystrybucja certyfikatów | Wydanie w CA, publikacja przez Łączność, dalej P2P i do Edge app | Wydawanie działa, dystrybucja niezdefiniowana |
| Dystrybucja kluczy prywatnych | Preferowany CSR (PKCS#10) na węźle; jeśli generuje serwer – zaszyfrowany PKCS#12 | Klucz zwracany w JSON przez HTTP |
| Dystrybucja CRL (stała łączność) | Łączność serwuje podpisaną CRL z bazy | Proxy do admina |
| Dystrybucja CRL (przerywana łączność) | Gossip P2P między węzłami (pkt 4) | Brak (generyczny transfer plików) |
| Weryfikacja offline | Komponent „weryfikator + magazyn PKI” na węźle: łańcuch do Root CA, ważność, status w CRL | Tylko `scripts/demo_offline_auth.sh` |
| Nieaktualność danych | `CRLNumber`, polityka `nextUpdate` (okres łaski, hard/soft-fail), tolerancja zegara | `nextUpdate` = 30 dni, brak `CRLNumber` |
| Integralność przez pośredników | Weryfikacja podpisu CA + monotoniczność numeru CRL przed użyciem | Brak weryfikacji w P2P |

## 4. Docelowy protokół dystrybucji CRL między węzłami

Anti-entropy gossip na podpisanych obiektach – pośrednik nie musi być zaufany.

```
co T sekund (lub przy kontakcie z sąsiadem):
  A → B:  GET /pki/summary
          ← { ca_fingerprint, crl_number, crl_this_update, certs_version }
  jeśli B.crl_number > A.crl_number:
          A → B: GET /pki/crl  → DER
          A weryfikuje:
            1. podpis kluczem z lokalnego cert CA (trust anchor)
            2. issuer == subject CA, AKI == SKI CA
            3. crl_number > lokalny  (ochrona przed rollbackiem)
            4. thisUpdate <= now + skew_tolerance
          OK  → zapis atomowy, log, powiadomienie pozostałych sąsiadów
          NIE → odrzucenie + log
  symetrycznie B pobiera od A
```

- Zaufanie wynika wyłącznie z **podpisu CA** i **monotonicznego `CRLNumber`** (RFC 5280 §5.2.3).
- Jedna (najnowsza) pełna CRL na węzeł – brak konfliktów, porównanie liczb.
- Ten sam mechanizm dla certyfikatów i rolloveru certyfikatu CA.
- Delta-CRL – opcjonalnie, jako pomiar porównawczy.
- Brak świeżej CRL → węzeł raportuje „PKI nieaktualne od X h” i stosuje politykę świeżości.

## 5. Główne zagrożenia do opisania w pracy

1. Klucz Root CA w kontenerze online (docelowo: Root offline + Issuing CA – przynajmniej opis).
2. Rollback/freeze attack – pośrednik podaje starą, poprawnie podpisaną CRL → `CRLNumber`.
3. Klucz prywatny przesyłany jawnie → CSR lub zaszyfrowany PKCS#12.
4. Brak uwierzytelniania P2P (spam, zaśmiecanie węzła) → podpis wiadomości certyfikatem węzła lub mTLS.
5. Rozjazd zegara węzłów odciętych od sieci → tolerancja, polityka.
6. SPOF (jedna CA, baza, Łączność) – akceptowalne, P2P maskuje niedostępność centrum.

## 6. Scenariusze testów i metryki

1. Odwołanie certyfikatu, gdy węzeł B jest offline, A online → czas, po którym B odrzuca certyfikat.
2. Odcięcie węzła na N dni (krótkie `nextUpdate` / przesunięcie zegara) → zachowanie przed `nextUpdate`, w okresie łaski, po nim.
3. Złośliwy pośrednik: zmodyfikowana CRL (podpis), starsza CRL (`CRLNumber`), CRL od obcego CA.
4. Rozjazd zegara ±Δ → fałszywe akceptacje / odrzucenia.
5. Łańcuch A→B→C (wiele skoków) przy różnych wzorcach dostępności.

Metryki: czas propagacji, liczba skoków, narzut transferu (pełna CRL vs delta), odsetek poprawnych decyzji.

## 7. Proponowany spis treści pracy

1. Wstęp
2. Infrastruktura klucza publicznego – X.509/RFC 5280, cykl życia certyfikatu, CRL/delta-CRL/OCSP, PKCS#10/#12, SCEP/EST, przegląd OpenSSL CA / EJBCA / Dogtag
3. PKI w warunkach ograniczonej łączności – problem, ograniczenia mechanizmów, model zagrożeń, wymagania
4. Projekt systemu – architektura (cały diagram), CA (Panel), publikacja (PostgreSQL + Łączność), węzeł brzegowy (Edge client), protokół P2P, polityka świeżości, Edge app, analiza bezpieczeństwa
5. Implementacja
6. Testy i demonstracja
7. Podsumowanie

## 8. Możliwe uproszczenia

- Edge app jako prosty konsument certyfikatu (lub połączona z Edge client).
- Pełna CRL zamiast delta-CRL; OCSP tylko teoretycznie.
- Bez mTLS w P2P (integralność z podpisu CA), opisane jako ograniczenie.
- Jeden poziom CA, model Root + Issuing tylko opisany.
- Symulacja czasu krótkimi okresami `nextUpdate` i przesuwaniem zegara.
